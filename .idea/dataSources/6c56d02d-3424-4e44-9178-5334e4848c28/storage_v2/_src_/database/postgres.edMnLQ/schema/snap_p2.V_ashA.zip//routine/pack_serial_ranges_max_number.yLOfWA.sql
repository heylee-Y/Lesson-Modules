create function "pack_serial_ranges$max_number"(e1 double precision, e2 double precision) returns double precision
    language plpgsql
as
$$
BEGIN
    IF e1 > e2 THEN
        RETURN e1;
    ELSE
        RETURN e2;
    END IF;
END;

$$;

alter function "pack_serial_ranges$max_number"(double precision, double precision) owner to shr_psql_prod;

