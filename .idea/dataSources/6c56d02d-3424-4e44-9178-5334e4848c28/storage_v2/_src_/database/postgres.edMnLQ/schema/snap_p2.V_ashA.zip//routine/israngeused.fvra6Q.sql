create function israngeused(formcodeid double precision, startnumber double precision, endnumber double precision) returns boolean
    language plpgsql
as
$$
DECLARE
    result BOOLEAN DEFAULT FALSE;
/* check if the range is into a single block */
/*
select sn.status
from SERIALNUMBERUSAGE sn
where sn.formcode_id = formCodeID AND
      sn.serialnumberstart <= startNumber AND
      sn.serialnumberstart + sn.quantity >= endNumber;
*/
BEGIN
    RETURN (result);
END;

$$;

alter function israngeused(double precision, double precision, double precision) owner to shr_psql_prod;

