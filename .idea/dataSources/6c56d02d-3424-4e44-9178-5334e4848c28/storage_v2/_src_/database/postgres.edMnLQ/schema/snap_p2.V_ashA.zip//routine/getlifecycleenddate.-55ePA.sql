create function getlifecycleenddate(v_fromcodeid numeric, d_lifecyclestartdate timestamp without time zone) returns timestamp without time zone
  language plpgsql
as
$$
DECLARE
    selectQuery CHARACTER VARYING(500);
    endDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT aws_oracle_ext.SYSDATE();
BEGIN
    SELECT
        *
        INTO STRICT endDate
        FROM (SELECT
            t.update_date
            FROM snap_p2.formhistory AS t
            WHERE t.formcode_id = v_fromcodeid AND t.update_date > d_lifecyclestartdate
            ORDER BY t.update_date ASC) AS var_sbq
        LIMIT 1;
    RETURN endDate;
    EXCEPTION
        WHEN others THEN
            RETURN aws_oracle_ext.SYSDATE();
END;

$$;

alter function getlifecycleenddate(numeric, timestamp) owner to shr_psql_prod;

