create function historize(formcodeid numeric, snapnumber numeric DEFAULT NULL::numeric, startnumber numeric DEFAULT NULL::numeric, endnumber numeric DEFAULT NULL::numeric, quantity numeric DEFAULT 1, bspid numeric DEFAULT NULL::numeric, bspoldid numeric DEFAULT NULL::numeric, doctypeid numeric DEFAULT NULL::numeric, docsubtypeid numeric DEFAULT NULL::numeric, gdsid numeric DEFAULT NULL::numeric, printerid numeric DEFAULT NULL::numeric, validitydate timestamp without time zone DEFAULT NULL::timestamp without time zone, purchaseorder text DEFAULT NULL::text, statuscode text DEFAULT NULL::text, frozendate timestamp without time zone DEFAULT NULL::timestamp without time zone, historyreferencedid numeric DEFAULT NULL::numeric, retrievestatus text DEFAULT NULL::text, snapbulletin numeric DEFAULT NULL::numeric, OUT errorcode numeric, rangestatus text DEFAULT NULL::text, operationdate timestamp without time zone DEFAULT NULL::timestamp without time zone) returns numeric
  language plpgsql
as
$$
DECLARE
    v_operationDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(operationdate, aws_oracle_ext.SYSDATE());
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    INSERT INTO snap_p2.history (id, formcodeid, startno, endno, status, historydate, snapnumber, quantity, bspid, gdsid, doctypeid, docsubtypeid, printerid, bspoldid, purchasenumber, freezedate, validitydate, allocationdate, statuschangedate, createdate, history_id, retrieve_status, snapbulletinno, rangestatus)
    VALUES (nextval('snap_p2.history_id_sequence'), formcodeid, startnumber, endnumber, statuscode, v_operationDate, snapnumber, quantity, bspid, gdsid, doctypeid, docsubtypeid, printerid, bspoldid, purchaseorder, frozendate, validitydate, v_operationDate, v_operationDate, v_operationDate, historyreferencedid, retrievestatus, snapbulletin, rangestatus);
    errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;
    EXCEPTION
        WHEN others THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_HISTORICIZE')::NUMERIC;
END;

$$;

alter function historize(numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, timestamp, text, text, timestamp, numeric, text, numeric, out numeric, text, timestamp) owner to shr_psql_prod;

