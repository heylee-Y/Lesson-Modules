create function getallocationsforfilter(p_formcodeid double precision, p_bspid double precision, p_printerid double precision, p_startnumber double precision, p_endnumber double precision, OUT p_errorcode double precision, OUT p_outallocation refcursor) returns record
  language plpgsql
as
$$
DECLARE
    v_sql CHARACTER VARYING(2000) DEFAULT CONCAT_WS('', 'select AI, AF, S,E , sn.serialnumberstart SS, sn.serialnumberstart + sn.quantity -1 SE, sn.status FROM ', '( ', 'select t.id AI, t.formcode_id AF , t.startnumber S, t.endnumber E from allocation t ', 'where ', '     ( ', '       ( :formcode is null OR t.formcode_id = :formcode ) AND ', '       ( :bsp is null OR t.bsp_id = :bsp ) AND ', '       ( :printer is null OR t.printer_id = :printer ) AND ', '       ( :s is null OR :e is  null OR ', '             isoverlapping2( t.startnumber , t.endnumber , :s , :e ) = 1 ) ', '     )', 'order by t.startnumber ', ') inner join serialnumberusage sn on sn.formcode_id = AF ', 'where ', '      isoverlapping( sn.serialnumberstart, sn.quantity, S , E ) = 1 ', 'order by S asc, SS asc ');
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init()
    /*
    [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
    open p_outAllocation for v_sql using
                        p_formcodeId, p_formcodeId,
                        p_bspId, p_bspId,
                        p_printerId, p_printerId,
                        p_startNumber, p_endNumber,
                        p_startNumber, p_endNumber
    */;
    p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;
    EXCEPTION
        WHEN others THEN
            RAISE DEBUG USING MESSAGE := SQLERRM;
            p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
END;

$$;

alter function getallocationsforfilter(double precision, double precision, double precision, double precision, double precision, out double precision, out refcursor) owner to shr_psql_prod;

