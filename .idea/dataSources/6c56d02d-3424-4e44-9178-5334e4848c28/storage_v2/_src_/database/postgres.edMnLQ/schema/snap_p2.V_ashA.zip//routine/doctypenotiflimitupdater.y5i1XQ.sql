create function doctypenotiflimitupdater() returns void
  language plpgsql
as
$$
  /* calculate free space form all formcodes */
BEGIN
    UPDATE snap_p2.documenttypes AS upddt
    SET dt_limitexceeded = (SELECT
        CASE SIGN(SUM(free) / SUM(total) * 100 - notif)
            WHEN - 1 THEN 1
            ELSE 0
        END
        FROM (SELECT
            dt.id AS dtid, fc.id AS fcid, COALESCE(dt.dt_notificationlimit, 0) AS notif,
            CASE LENGTH(fc.fc_number)
                WHEN 2 THEN 100000000
                WHEN 3 THEN 10000000
                ELSE 10000000
            END AS total, SUM(sn.quantity) AS free
            FROM snap_p2.serialnumberusage AS sn
            INNER JOIN snap_p2.formcode AS fc
                ON fc.id = sn.formcode_id
            INNER JOIN snap_p2.documenttypes AS dt
                ON dt.id = fc.fc_documenttype_id
            WHERE sn.status IN ('F', 'RA')
            GROUP BY dt.id, dt.dt_notificationlimit, fc.id, fc.fc_number) AS var_sbq
        WHERE dtid = upddt.id
        GROUP BY dtid, notif);
END;

$$;

alter function doctypenotiflimitupdater() owner to shr_psql_prod;

