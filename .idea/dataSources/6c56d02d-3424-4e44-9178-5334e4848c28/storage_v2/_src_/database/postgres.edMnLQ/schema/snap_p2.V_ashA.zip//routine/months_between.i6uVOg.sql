create function months_between(t_start timestamp without time zone, t_end timestamp without time zone) returns integer
    immutable
    strict
    language sql
as
$$
SELECT
            (
                12 * extract('years' from a.i) + extract('months' from a.i)
            )::integer
        from (
            values (justify_interval($2 - $1))
        ) as a (i)


$$;

alter function months_between(timestamp, timestamp) owner to shr_psql_prod;

