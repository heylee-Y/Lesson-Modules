create function recycle(fc_id numeric, fc_override text, OUT errorcode integer, recycledate timestamp without time zone) returns integer
  language plpgsql
as
$$
DECLARE
    isValidForm NUMERIC(38) DEFAULT - 1;
    noAllocations NUMERIC(38) DEFAULT 0;
    snUsed REFCURSOR;
    snId NUMERIC(38);
    v_recycleDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(recycledate, aws_oracle_ext.SYSDATE());
    v_maxQuantity NUMERIC(38) DEFAULT aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'FC_MAXQUANTITY')::NUMERIC;
    v_FormCode NUMERIC(38) DEFAULT 0;
    v_FormCode_chk NUMERIC(38);
    v_doctype NUMERIC(38) DEFAULT NULL;
    v_HIST_CNT DOUBLE PRECISION DEFAULT 0;
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    SELECT
        COUNT(*)
        INTO STRICT isValidForm
        FROM snap_p2.formcode AS fc
        WHERE fc.id = fc_id;

    IF isValidForm = 0 THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_FORMCODE')::NUMERIC;
        RETURN;
    END IF;
    SELECT
        COUNT(*)
        INTO STRICT noAllocations
        FROM snap_p2.allocation AS al
        WHERE al.formcode_id = fc_id
    /* if there are allocations , they are deleted in case of override option */
    /* CR 538 : the fc_override forces the procedure overlook the allocations made for the form code */
    /* continue with the recycle. */;

    IF noAllocations > 0 AND fc_override != aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FORMCODE_OVERRIDE') THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RECYCLE_HASALLOCATION')::NUMERIC;
        RETURN;
    END IF;
    OPEN snUsed FOR
    SELECT
        id
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = fc_id
        FOR UPDATE;

    LOOP
        FETCH snUsed INTO snId;
        EXIT WHEN (NOT FOUND);
        DELETE FROM snap_p2.serialnumberusage
            WHERE id = snId;
    END LOOP;
    CLOSE snUsed;
   
   SELECT
        fc.fc_number, fc.fc_documenttype_id, length(fc.fc_number)
        INTO  v_FormCode, v_doctype,v_FormCode_chk
        FROM snap_p2.formcode AS fc
        WHERE fc.id = fc_id;

    IF (v_FormCode > 100) THEN
        v_maxQuantity := v_maxQuantity;
    ELSIF (v_FormCode_chk = 2) THEN
        v_maxQuantity := v_maxQuantity * 10;
    ELSIF (v_FormCode_chk = 3) THEN
        v_maxQuantity := v_maxQuantity;
    END IF
		
    /* end add :44760 */;
    INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
    VALUES (nextval('snap_p2.serialnumberusage_id_sequence'), fc_id, v_FormCode * v_maxQuantity, v_maxQuantity, aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_FREE'), v_recycleDate, NULL, NULL, NULL)
    /* issue 0010417 : SRS 4.1.13.2 : the AA  ranges should be removed (don't need to keep in history). */;
    SELECT
        COUNT(*)
        INTO STRICT v_HIST_CNT
        FROM snap_p2.history AS h
        WHERE h.formcodeid = fc_id AND h.rangestatus IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I'));

    IF v_HIST_CNT > 0 THEN
        DELETE FROM snap_p2.history AS hh
            WHERE hh.formcodeid = fc_id AND hh.rangestatus IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I'));
    END IF
    /* if the recycle is by override */;

    IF fc_override = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FORMCODE_OVERRIDE')
    /* historize the allocation, set the status as OVERRIDE */
    THEN
        SELECT
            *
            FROM snap_p2.historize(formcodeid := fc_id, doctypeid := v_doctype, startnumber := v_FormCode * v_maxQuantity, endnumber := (v_FormCode * v_maxQuantity + v_maxQuantity - 1), quantity := v_maxQuantity, statuscode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FORMCODE_OVERRIDE'), rangestatus := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_FREE'), operationdate := v_recycleDate)
            INTO errorcode;
        INSERT INTO snap_p2.formhistory (id, formcode_id, fc_number, fc_documenttype_id, fc_comment, fc_reso, update_date, fc_frozen, fc_frozen_for, fc_rcy_ready, is_overridden)
        SELECT
            nextval('snap_p2.fchistory_id_sequence'), fc.id, fc.fc_number, fc.fc_documenttype_id, fc.fc_comment, fc.fc_reso, aws_oracle_ext.SYSDATE(), NULL, NULL, NULL, 'Y'
            FROM snap_p2.formcode AS fc
            WHERE fc.id = fc_id;
    /* historize the allocation, with normal status */
    ELSE
        SELECT
            *
            FROM snap_p2.historize(formcodeid := fc_id, doctypeid := v_doctype, startnumber := v_FormCode * v_maxQuantity, endnumber := (v_FormCode * v_maxQuantity + v_maxQuantity - 1), quantity := v_maxQuantity, statuscode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_RECYCLE'), rangestatus := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_FREE'), operationdate := v_recycleDate)
            INTO errorcode;
        INSERT INTO snap_p2.formhistory (id, formcode_id, fc_number, fc_documenttype_id, fc_comment, fc_reso, update_date, fc_frozen, fc_frozen_for, fc_rcy_ready)
        SELECT
            nextval('snap_p2.fchistory_id_sequence'), fc.id, fc.fc_number, fc.fc_documenttype_id, fc.fc_comment, fc.fc_reso, aws_oracle_ext.SYSDATE(), NULL, NULL, NULL
            FROM snap_p2.formcode AS fc
            WHERE fc.id = fc_id;
    END IF;
    EXCEPTION
        WHEN others THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
            RAISE DEBUG USING MESSAGE := SQLERRM;
END;


$$;

alter function recycle(numeric, text, out integer, timestamp) owner to shr_psql_prod;

