create function "pack_serial_ranges$findparticalfreerange"(p_formcodeid numeric, p_quantity numeric, p_blacklistpercent numeric, p_nrinteruptions numeric, p_startingfromnumber numeric, INOUT p_opennumber numeric DEFAULT NULL::numeric, INOUT p_closenumber numeric DEFAULT NULL::numeric) returns record
  language plpgsql
as
$$
DECLARE
    V_ROWBLACKSN snap_p2.blacklistsn%ROWTYPE;
    C_BLACKLISTSN REFCURSOR;
    V_FOUND NUMERIC(38);
    V_DIFF NUMERIC(38);
    V_COUNT_BREAKS NUMERIC(38);
    V_COUNT_BLACK_NUMBERS NUMERIC(38);
    V_PERCENT_BLACKSN numeric;
    V_TEMP_OPENNUMBER numeric;
    V_TEMP_CLOSENUMBER numeric;
    v_rangeStart numeric DEFAULT NULL;
    v_rangeEnd numeric DEFAULT NULL;
    f$result BOOLEAN;
/* Pas 1:  se cauta primul range free (utilizand p_startingFromNumber) */
/* (este un cursor) */
/* Pas 2:  se testeaza in acest range daca putem obtine intervalul dorit(p_quantity, p_blackListPercent, p_nrInteruptions) */
/* aici am un cursor */
/* daca o zona a range-ului nu corespunde criteriilor trec la range-ul urmator SI/sau caut dupa blocul de blacklistnumbers !? */
/* daca am gasit ies */
/* end pas 2 */
/* end pas 1 */
BEGIN
    p_opennumber := - 1;
    p_closenumber := - 1
    /* initializearza p_openNumber cu start number daca e nenul */;

    IF COALESCE(p_startingfromnumber, - 1) > - 1 THEN
        v_rangeStart := p_startingfromnumber;
        v_rangeEnd := p_startingfromnumber;
    END IF;
    SELECT
        *
        FROM snap_p2.pack_serial_ranges$get_next_range_tosearch(p_formcodeid, v_rangeStart)
        INTO v_rangeStart, v_rangeEnd, f$result;

    WHILE f$result
    /* calculez cate black numbers am in intervalul asta , daca am */
    /* V_COUNT_BLACK_NUMBERS := CALCULATE_BLACKLIST_NUMBERS_IN_INTERVAL( P_FORMCODEID, P_OPENNUMBER, P_OPENNUMBER + P_QUANTITY -1 ); */
    LOOP
        V_COUNT_BLACK_NUMBERS := snap_p2.pack_serial_ranges$get_blacklist_quantity(p_formcodeid, v_rangeStart, v_rangeStart + p_quantity - 1)
        /* QUANTITY ESTE PREA MARE...ATUNCI IES */
        /* COMPARARE DE POZITII */
        /* IF NVL(P_QUANTITY, 0) /*+ NVL(V_COUNT_BLACK_NUMBERS, 0)*/ > (v_rangeEnd - v_rangeStart +1)  THEN */
        /* GOTO NEXT_RANGE; */
        /* END IF; */
        /* If the available amount is less than 1000, it will need to be frozen by admin. */;

        IF (v_rangeEnd - v_rangeStart + 1) < 1000
        /* + Left number should be greater than 1000 */
        THEN
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_RANGE
            */
            BEGIN
            END;
        END IF;

        IF COALESCE(p_quantity, 0) > (v_rangeEnd - v_rangeStart + 1) THEN
            p_opennumber := v_rangeStart;
            p_closenumber := v_rangeEnd /* + Allocation all the available number */;
        ELSE
            p_opennumber := v_rangeStart;
            p_closenumber := p_opennumber + COALESCE(p_quantity, 0) -
            /* + NVL(V_COUNT_BLACK_NUMBERS, 0) */
            1;
        END IF
        /* INCERC PRIMUL INTERVAL DE MARIME [ P_QUANTITY + V_COUNT_BLACK_NUMBERS ] SI CAUT BLACKNUMBERS */
        /* CAUT DOAR BLACKNUMBERS DIN RANGE-UL CURENT */
        /* V_COUNT_BREAKS := CALCULATE_BLACKLIST_INTRERUPTIONS_IN_INTERVAL( P_FORMCODEID, P_OPENNUMBER, P_CLOSENUMBER ); */;
        SELECT
            COUNT(*)
            INTO STRICT V_COUNT_BREAKS
            FROM snap_p2.blacklistsn
            WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, p_opennumber, p_closenumber) = 1;

        IF COALESCE(p_nrinteruptions, - 1) <> - 1 AND V_COUNT_BREAKS > p_nrinteruptions
        /* SE INCEPE EXACT DE LA p_startingFromNumber */
        /* IF NVL(p_startingFromNumber, -1) <> -1 THEN  --deci range-ul asta deja nu e bun si trec la urmatorul */
        /* V_FOUND := 0; */
        /* GOTO NEXT_RANGE; */
        /* ELSE */
        /* TO DO , DE MUTAT IN RANGE STARTING POINT..... */
        /* CAUT INCEPAND CU UN NUMAR IMEDIAT URMATOR UNEI ZONE DE BLACKNUMBERE */
        THEN
            OPEN C_BLACKLISTSN FOR
            SELECT
                *
                FROM snap_p2.blacklistsn
                WHERE formcode_id = p_formcodeid AND opennumber >= p_opennumber
            /* IAU IN CONSIDERARE NUMAI BLACKNUMBERE DE SUNT "DUPA" ZONA MEA */
                ORDER BY opennumber;

            LOOP
                FETCH C_BLACKLISTSN INTO V_ROWBLACKSN;
                EXIT WHEN (NOT FOUND);
                V_TEMP_OPENNUMBER := V_ROWBLACKSN.closenumber + 1
                /* DACA AM BLACKNUMBERE TREBUIE SA EXTIND INTERVALUL : */;
                SELECT
                    SUM(closenumber - opennumber + 1)
                    /* AM: adaug +1 (cantitatea = end-st +1 ) */
                    INTO STRICT V_COUNT_BLACK_NUMBERS
                    FROM snap_p2.blacklistsn
                    WHERE formcode_id = p_formcodeid AND opennumber >= V_TEMP_OPENNUMBER AND closenumber <= V_TEMP_OPENNUMBER + p_quantity
                /* DEPASESC RANGE-UL CURENT */;

                IF COALESCE(V_TEMP_OPENNUMBER, 0) + COALESCE(p_quantity, 0) >
                /* + NVL(V_COUNT_BLACK_NUMBERS, 0) */
                v_rangeEnd THEN
                    /*
                    [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                    GOTO NEXT_RANGE
                    */
                    BEGIN
                    END;
                END IF;
                V_TEMP_CLOSENUMBER := V_TEMP_OPENNUMBER + COALESCE(p_quantity, 0) -
                /* + NVL(V_COUNT_BLACK_NUMBERS, 0) */
                1
                /* caut din nou nr-ul de intreruperi */;
                SELECT
                    COUNT(*)
                    INTO STRICT V_COUNT_BREAKS
                    FROM snap_p2.blacklistsn
                    WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, V_TEMP_OPENNUMBER, V_TEMP_CLOSENUMBER) = 1;

                IF COALESCE(V_COUNT_BREAKS, 0) > p_nrinteruptions AND COALESCE(p_nrinteruptions, - 1) <> - 1 THEN
                    /*
                    [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                    GOTO NEXT_BLACKLIST
                    */
                    BEGIN
                    END;
                END IF
                /* VERIFIC PROCENTUL DE BLACKNUMBERS */;
                SELECT
                    (SUM(snap_p2.pack_serial_ranges$min_number(closenumber, V_TEMP_CLOSENUMBER) - snap_p2.pack_serial_ranges$max_number(opennumber, V_TEMP_OPENNUMBER) + 1) / p_quantity) * 100
                    INTO STRICT V_PERCENT_BLACKSN
                    FROM snap_p2.blacklistsn
                    WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, V_TEMP_OPENNUMBER, V_TEMP_CLOSENUMBER) = 1
                    ORDER BY opennumber ASC;

                IF (COALESCE(V_PERCENT_BLACKSN, 0) > p_blacklistpercent AND COALESCE(p_blacklistpercent, - 1) <> - 1) THEN
                    /*
                    [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                    GOTO NEXT_BLACKLIST
                    */
                    BEGIN
                    END;
                /* ZONA ESTE BUNA */
                ELSE
                    p_opennumber := V_TEMP_OPENNUMBER;
                    p_closenumber := V_TEMP_CLOSENUMBER;
                    CLOSE C_BLACKLISTSN
                    /*
                    [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                    GOTO SUCCESS
                    */;
                END IF;
            END LOOP;
            CLOSE C_BLACKLISTSN
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_RANGE
            */;
        /* p_nrInteruptions NU CONTEAZA SAU ZONA INDEPLINESTE CONDITIA */
        ELSE
            NULL;
        END IF;
        SELECT
            (SUM(snap_p2.pack_serial_ranges$min_number(closenumber, p_closenumber) - snap_p2.pack_serial_ranges$max_number(opennumber, p_opennumber) + 1) / p_quantity) * 100
            INTO STRICT V_PERCENT_BLACKSN
            FROM snap_p2.blacklistsn
            WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, p_opennumber, p_closenumber) = 1
            ORDER BY opennumber ASC;

        IF (COALESCE(V_PERCENT_BLACKSN, 0) > p_blacklistpercent AND COALESCE(p_blacklistpercent, - 1) <> - 1) THEN
            IF COALESCE(p_startingfromnumber, - 1) <> - 1
            /* deci range-ul asta deja nu e bun si trec la urmatorul */
            THEN
                /*
                [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                GOTO NEXT_RANGE
                */
                BEGIN
                END;
            /* TO DO , DE MUTAT IN RANGE STARTING POINT..... */
            /* CAUT INCEPAND CU UN NUMAR IMEDIAT URMATOR UNEI ZONE DE BLACKNUMBERE */
            ELSE
                OPEN C_BLACKLISTSN FOR
                SELECT
                    *
                    FROM snap_p2.blacklistsn
                    WHERE formcode_id = p_formcodeid AND opennumber >= p_opennumber
                /* IAU IN CONSIDERARE NUMAI BLACKNUMBERE DE SUNT "DUPA" ZONA MEA */
                    ORDER BY opennumber;

                LOOP
                    FETCH C_BLACKLISTSN INTO V_ROWBLACKSN;
                    EXIT WHEN (NOT FOUND);
                    V_TEMP_OPENNUMBER := V_ROWBLACKSN.closenumber + 1
                    /* DACA AM BLACKNUMBERE TREBUIE SA EXTIND INTERVALUL : */;
                    SELECT
                        SUM(closenumber - opennumber + 1)
                        /* AM: adaug +1 (cantitatea = end-st +1 ) */
                        INTO STRICT V_COUNT_BLACK_NUMBERS
                        FROM snap_p2.blacklistsn
                        WHERE formcode_id = p_formcodeid AND opennumber >= V_TEMP_OPENNUMBER AND closenumber <= V_TEMP_OPENNUMBER + p_quantity
                    /* DEPASESC RANGE-UL CURENT */;

                    IF COALESCE(V_TEMP_OPENNUMBER, 0) + COALESCE(p_quantity, 0) >
                    /* + NVL(V_COUNT_BLACK_NUMBERS, 0) */
                    v_rangeEnd THEN
                        /*
                        [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                        GOTO NEXT_RANGE
                        */
                        BEGIN
                        END;
                    END IF;
                    V_TEMP_CLOSENUMBER := V_TEMP_OPENNUMBER + COALESCE(p_quantity, 0) -
                    /* + NVL(V_COUNT_BLACK_NUMBERS, 0) */
                    1
                    /* caut din nou nr-ul de intreruperi */;
                    SELECT
                        COUNT(*)
                        INTO STRICT V_COUNT_BREAKS
                        FROM snap_p2.blacklistsn
                        WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, V_TEMP_OPENNUMBER, V_TEMP_CLOSENUMBER) = 1;

                    IF COALESCE(V_COUNT_BREAKS, 0) > p_nrinteruptions AND COALESCE(p_nrinteruptions, - 1) <> - 1 THEN
                        /*
                        [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                        GOTO NEXT_BLACKLIST
                        */
                        BEGIN
                        END;
                    END IF
                    /* VERIFIC PROCENTUL DE BLACKNUMBERS */;
                    SELECT
                        (SUM(snap_p2.pack_serial_ranges$min_number(closenumber, V_TEMP_CLOSENUMBER) - snap_p2.pack_serial_ranges$max_number(opennumber, V_TEMP_OPENNUMBER) + 1) / p_quantity) * 100
                        INTO STRICT V_PERCENT_BLACKSN
                        FROM snap_p2.blacklistsn
                        WHERE formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(opennumber, closenumber, V_TEMP_OPENNUMBER, V_TEMP_CLOSENUMBER) = 1
                        ORDER BY opennumber ASC;

                    IF (COALESCE(V_PERCENT_BLACKSN, 0) > p_blacklistpercent AND COALESCE(p_blacklistpercent, - 1) <> - 1) THEN
                        /*
                        [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                        GOTO NEXT_BLACKLIST
                        */
                        BEGIN
                        END;
                    /* ZONA ESTE BUNA */
                    ELSE
                        p_opennumber := V_TEMP_OPENNUMBER;
                        p_closenumber := V_TEMP_CLOSENUMBER;
                        CLOSE C_BLACKLISTSN
                        /*
                        [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                        GOTO SUCCESS
                        */;
                    END IF;
                END LOOP;
                CLOSE C_BLACKLISTSN;
                V_FOUND := 0
                /*
                [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                GOTO NEXT_RANGE
                */;
            END IF;
        /* p_blackListPercent nu conteaza SAU ZONA INDEPLINESTE CONDITIA */
        ELSE
            NULL;
        END IF
        /* DACA AM AJUNS AICI E OK , ZONA E BUNA */
        /*
        [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
        GOTO SUCCESS
        */;
        v_rangeStart := v_rangeEnd + 1;
    END LOOP;
    p_opennumber := - 1;
    p_closenumber := - 1;
    NULL;
END;

$$;

alter function "pack_serial_ranges$findparticalfreerange"(numeric, numeric, numeric, numeric, numeric, inout numeric, inout numeric) owner to shr_psql_prod;

