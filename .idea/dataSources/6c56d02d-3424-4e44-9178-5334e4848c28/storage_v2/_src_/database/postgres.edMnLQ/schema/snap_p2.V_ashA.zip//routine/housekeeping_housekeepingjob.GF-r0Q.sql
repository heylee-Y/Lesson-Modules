create function "housekeeping$housekeepingjob"() returns void
    language plpgsql
as
$$
DECLARE
    c_formcodes CURSOR FOR
    SELECT
        id
        FROM snap_p2.formcode AS f
    /* WHERE F.FC_ACTIVE = 1 */;
    V_ID NUMERIC(38);
    c_formcodes$FOUND BOOLEAN DEFAULT false;
BEGIN
    OPEN c_formcodes;

    LOOP
        FETCH c_formcodes INTO V_ID;
        c_formcodes$FOUND := FOUND;
        EXIT WHEN (NOT c_formcodes$FOUND);
        PERFORM snap_p2.housekeeping$compactformcode(V_ID);
    END LOOP;
    CLOSE c_formcodes;
    EXCEPTION
        WHEN others THEN
            RAISE DEBUG USING MESSAGE := SQLERRM;
END;

$$;

alter function "housekeeping$housekeepingjob"() owner to shr_psql_prod;

