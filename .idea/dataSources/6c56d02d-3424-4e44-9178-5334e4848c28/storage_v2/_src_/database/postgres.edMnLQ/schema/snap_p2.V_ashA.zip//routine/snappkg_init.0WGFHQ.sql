create function "snappkg$init"() returns void
    language plpgsql
as
$$
BEGIN
if aws_oracle_ext.is_package_initialized
      ( 'SNAP_P2', 'SNAPPKG' ) then
      return;
    end if;
    perform aws_oracle_ext.set_package_initialized
      ( 'SNAP_P2', 'SNAPPKG' );

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'CT_FALSE', 0);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'CT_TRUE', 1);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_FORMCODE_FREEZE', 10);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_HISTORICIZE', 5);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_FORMCODE', 4);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS', 7);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_RANGE', 2);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_RANGE_NOT_FREE', 3);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_IS_USED', 9);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_NOT_FOUND', 8);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_RECYCLE_HASALLOCATION', 6);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN', 1);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'FC_MAXQUANTITY', 10000000);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'FC_MAXQUANTITY2', 100000000);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'FC_STARTNUMBER', 0);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA', 'AA'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB', 'AB'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_D', 'D'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I', 'I'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_BLACKLISTED', 'B'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_FREE', 'F'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_RETRIEVE_A', 'RA'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_RETRIEVE_Q', 'RQ'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_ALLOCATION', 'ALL'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_AUTORETRIEVAL', 'ATRQ'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_BLSINCHRO', 'BLSY'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_DUMMY_SNAP_BULLETIN', 'SBL'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FEEDBACKSINCHRO', 'FBS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FORMCODE_OVERRIDE', 'OVERRIDE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_FREEZE', 'FRZ'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_MERGE', 'MRG'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_REASONFORRETRIEVAL', 'PFR'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_RECYCLE', 'REC'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_RETRIEVE', 'RET'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_SPLIT', 'SP'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'ST_TRANSFER', 'TRN'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK', 0);
END;

$$;

alter function "snappkg$init"() owner to shr_psql_prod;

