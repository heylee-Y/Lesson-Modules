create function calc_max_sn(serialnumber double precision) returns double precision
    language plpgsql
as
$$
DECLARE
    closeNo NUMERIC(38) DEFAULT 0;
    v_TEMP_FC_NUMBER NUMERIC(38) DEFAULT 0;
BEGIN
    SELECT
        fc_number
        INTO STRICT v_TEMP_FC_NUMBER
        FROM snap_p2.formcode
        WHERE (fc_number = SUBSTR(serialnumber, 1, 2) OR fc_number = SUBSTR(serialnumber, 1, 3));

    IF LENGTH(v_TEMP_FC_NUMBER) = 2 THEN
        closeNo := (v_TEMP_FC_NUMBER * 100000000) + 99999999;
    ELSIF LENGTH(v_TEMP_FC_NUMBER) = 3 THEN
        closeNo := (v_TEMP_FC_NUMBER * 10000000) + 9999999;
    ELSE
        closeNo := 0;
    END IF;
    RETURN closeNo;
END;

$$;

alter function calc_max_sn(double precision) owner to shr_psql_prod;

