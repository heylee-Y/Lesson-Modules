create function splitformcode(p_formcodeid double precision, OUT o_errorcode double precision) returns double precision
  language plpgsql
as
$$
BEGIN
-- Converted with error!
END;

$$;

alter function splitformcode(double precision, out double precision) owner to shr_psql_prod;

