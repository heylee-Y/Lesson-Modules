create function isoverlapping(startno double precision, quantity double precision, openno double precision, closeno double precision) returns double precision
  language plpgsql
as
$$
BEGIN
    RETURN snap_p2.isoverlapping2(startno, startno + quantity - 1, openno, closeno);
END;

$$;

alter function isoverlapping(double precision, double precision, double precision, double precision) owner to shr_psql_prod;

