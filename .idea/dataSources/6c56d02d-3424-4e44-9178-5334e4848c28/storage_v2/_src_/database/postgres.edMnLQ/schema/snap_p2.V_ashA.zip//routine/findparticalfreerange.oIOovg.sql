create function findparticalfreerange(formcodeid numeric, quantity numeric, blacklistpercent numeric, nrinteruptions numeric, startingfromnumber numeric, OUT errorcode numeric, OUT opennumber numeric, OUT closenumber numeric) returns record
  language plpgsql
as
$$
DECLARE
    isValidForm NUMERIC(38) DEFAULT - 1;
    v_fcCode NUMERIC(38);
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    opennumber := - 1;
    closenumber := - 1
    /* <<validation>> */;
    SELECT
        fc.id, fc.fc_number
        INTO STRICT isValidForm, v_fcCode
        FROM snap_p2.formcode AS fc
        WHERE fc.id = formcodeid;

    IF isValidForm = - 1 THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_FORMCODE')::NUMERIC;
        RETURN;
    END IF;

    IF quantity <= 0 OR (v_fcCode < 100 AND quantity > aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'FC_MAXQUANTITY2')::NUMERIC) OR (v_fcCode >= 100 AND quantity > aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'FC_MAXQUANTITY')::NUMERIC) THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF;

    /* <<end validation>> */
    /* <<call>> */
    SELECT
        *
        FROM snap_p2.pack_serial_ranges$findparticalfreerange(formcodeid, quantity, COALESCE(blacklistpercent, - 1), COALESCE(nrinteruptions, - 1), COALESCE(startingfromnumber, - 1), p_opennumber := opennumber, p_closenumber := closenumber)
        INTO opennumber, closenumber;

    IF opennumber = - 1 OR opennumber IS NULL OR closenumber = - 1 OR closenumber IS NULL THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_NOT_FOUND')::NUMERIC;
        RETURN;
    END IF;
    errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;
    EXCEPTION
        WHEN others THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
END;

$$;

alter function findparticalfreerange(numeric, numeric, numeric, numeric, numeric, out numeric, out numeric, out numeric) owner to shr_psql_prod;

