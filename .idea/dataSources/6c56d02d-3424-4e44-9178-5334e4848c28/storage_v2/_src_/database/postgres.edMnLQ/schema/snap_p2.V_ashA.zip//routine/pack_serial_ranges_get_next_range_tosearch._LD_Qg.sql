create function "pack_serial_ranges$get_next_range_tosearch"(p_formcodeid numeric, p_startingfromnumber numeric, OUT o_ranges numeric, OUT o_rangee numeric, OUT "f$result" boolean) returns record
    language plpgsql
as
$$
DECLARE

    c_ranges CURSOR FOR

    SELECT

        snuse.serialnumberstart AS s, snuse.serialnumberstart + snuse.quantity - 1 AS e

        FROM snap_p2.formcode AS f

        INNER JOIN snap_p2.serialnumberusage AS snuse

            ON f.id = snuse.formcode_id

        WHERE (snuse.formcode_id = p_formcodeid)

                                                                AND (status = 'F' OR status = 'RA')

                                                                AND (COALESCE(p_startingfromnumber, - 1) = - 1 OR p_startingfromnumber BETWEEN snuse.serialnumberstart AND snuse.serialnumberstart + snuse.quantity - 1 OR snuse.serialnumberstart >= p_startingfromnumber)

                                                                AND f.id = p_formcodeid

        ORDER BY snuse.serialnumberstart;

    V_RANGES record;

    V_RANGE_START NUMERIC DEFAULT - 1;

    V_RANGE_END NUMERIC DEFAULT - 1;

    c_ranges$FOUND BOOLEAN DEFAULT false;

BEGIN

    PERFORM SNAP_P2.SNAPPKG$Init();

    OPEN c_ranges;

 

    LOOP

        FETCH c_ranges INTO V_RANGES;

        c_ranges$FOUND := FOUND;

        EXIT WHEN (NOT c_ranges$FOUND);

                                                               

                                                               

                                                                IF V_RANGE_START = - 1 THEN

                                                                    V_RANGE_START := V_RANGES.s;

            V_RANGE_END := V_RANGES.e;

                                                  ELSIF V_RANGES.s = V_RANGE_END + 1  THEN

                                                                    V_RANGE_END := V_RANGES.e;

                                                                ELSE

                                                                    EXIT;

                                                                END IF;

     

    END LOOP;

    CLOSE c_ranges;

 

    IF V_RANGE_START = - 1 THEN

        f$result := FALSE;

        RETURN;

    END IF;

    o_ranges := V_RANGE_START

    /* dummy check */;

 

    IF p_startingfromnumber > o_ranges THEN

        o_ranges := p_startingfromnumber;

    END IF;

    o_rangee := V_RANGE_END;

    f$result := TRUE;

    RETURN;

    EXCEPTION

        WHEN others THEN

            f$result := FALSE;

            RETURN;

END;

$$;

alter function "pack_serial_ranges$get_next_range_tosearch"(numeric, numeric, out numeric, out numeric, out boolean) owner to shr_psql_prod;

