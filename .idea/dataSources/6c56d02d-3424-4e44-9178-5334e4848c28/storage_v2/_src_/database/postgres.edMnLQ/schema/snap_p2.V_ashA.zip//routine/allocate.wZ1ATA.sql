create function allocate(formcodeid numeric, startnumber numeric, endnumber numeric, quantity numeric, gdsid numeric DEFAULT NULL::numeric, bspid numeric DEFAULT NULL::numeric, printerid numeric DEFAULT NULL::numeric, papertypeid numeric DEFAULT NULL::numeric, validitydate timestamp without time zone DEFAULT NULL::timestamp without time zone, purchaseordernumber text DEFAULT NULL::text, OUT errorcode numeric, OUT allocationid numeric, allocationdate timestamp without time zone DEFAULT NULL::timestamp without time zone) returns record
    language plpgsql
as
$$
DECLARE
    isValidForm NUMERIC(38) DEFAULT - 1;
    isFreeRange NUMERIC(38) DEFAULT 0;
    idOldSN NUMERIC(38) DEFAULT - 1;
    rangeStartNo numeric;
    rangeQuantity numeric;
    rangeEndNumber numeric;
    allocationQuantity numeric;
    newIDSN NUMERIC(38);
    tempQuantity numeric;
    documentTypeID NUMERIC(38);
    v_allocationDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(allocationdate, aws_oracle_ext.SYSDATE());
    c_ranges CURSOR FOR
    SELECT
        sn.id AS id, sn.serialnumberstart AS s, sn.serialnumberstart + sn.quantity - 1 AS e
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = formcodeid AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, startnumber, endnumber) = 1
        ORDER BY sn.serialnumberstart ASC;
    V_RANGES record;
    c_ranges$FOUND BOOLEAN DEFAULT false;
    c_r$FOUND BOOLEAN DEFAULT false;
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    allocationid := - 1
    /* VALIDATION */;

    IF endnumber < startnumber THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_RANGE_NOT_FREE')::NUMERIC;
        RETURN;
    END IF;
    allocationQuantity := endnumber - startnumber + 1;
    SELECT
        fc.id, fc.fc_documenttype_id
        INTO STRICT isValidForm, documentTypeID
        FROM snap_p2.formcode AS fc
        WHERE fc.id = formcodeid;

    IF isValidForm = - 1 THEN
        errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_FORMCODE')::NUMERIC;
        RETURN;
    END IF
    /* verification range */;

    DECLARE
        c_r CURSOR FOR
        SELECT
            sn.status
            FROM snap_p2.serialnumberusage AS sn
            WHERE sn.formcode_id = formcodeid AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, startnumber, endnumber) = 1;
        hasError BOOLEAN DEFAULT TRUE;
        V_R record;
    BEGIN
        OPEN c_r;

        LOOP
            FETCH c_r INTO V_R;
            c_r$FOUND := FOUND;
            EXIT WHEN (NOT c_r$FOUND);

            IF V_R.status IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_FREE'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_RETRIEVE_A')) THEN
                hasError := FALSE;
            ELSE
                hasError := TRUE;
                EXIT;
            END IF;
        END LOOP;
        CLOSE c_r;

        IF hasError THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_RANGE_NOT_FREE')::NUMERIC;
            RETURN;
        END IF;
    END;
    rangeEndNumber := rangeStartNo + rangeQuantity - 1
    /* end validation */
    /* broke old SN (idOldSN - pk ) in 3 ranges */
    /* 1 check if startNumber is at the beginig of range */
    /* <insert new record in allocation table>> */;
    SELECT
        nextval('snap_p2.allocation_id_sequence')
        INTO STRICT allocationid;
    INSERT INTO snap_p2.allocation (id, allocationdate, startnumber, quantity, endnumber, formcode_id, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
    VALUES (allocationid, v_allocationDate, startnumber, quantity, endnumber, formcodeid, documentTypeID, papertypeid, bspid, gdsid, printerid, validitydate, purchaseordernumber);
    OPEN c_ranges;

    LOOP
        FETCH c_ranges INTO V_RANGES;
        c_ranges$FOUND := FOUND;
        EXIT WHEN (NOT c_ranges$FOUND);

        IF V_RANGES.serialnumberstart <= startnumber AND endnumber <= V_RANGES.e
        /* broke record */
        THEN
            tempQuantity := startnumber - V_RANGES.serialnumberstart;

            IF tempQuantity > 0 THEN
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, sn.serialnumberstart, tempQuantity, sn.status, statuschangedate, allocation_id, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = V_RANGES.id;
            END IF;
            tempQuantity := V_RANGES.e - endnumber;

            IF tempQuantity > 0 THEN
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, endnumber + 1, tempQuantity, sn.status, statuschangedate, allocation_id, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = V_RANGES.id;
            END IF;
            DELETE FROM snap_p2.serialnumberusage
                WHERE id = V_RANGES.id
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_REC
            */;
        END IF;

        IF V_RANGES.serialnumberstart < startnumber
        /* <<freebegin>> */
        THEN
            tempQuantity := startnumber - V_RANGES.serialnumberstart;
            UPDATE snap_p2.serialnumberusage AS sn
            SET quantity = tempQuantity
                WHERE sn.id = V_RANGES.id
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_REC
            */;
        END IF;

        IF endnumber < V_RANGES.e
        /* <<freeEND>> */
        THEN
            tempQuantity := V_RANGES.e - endnumber;
            UPDATE snap_p2.serialnumberusage AS sn
            SET serialnumberstart = endnumber + 1, quantity = tempQuantity
                WHERE sn.id = V_RANGES.id
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_REC
            */;
        END IF
        /* delete intermediate ranges */;

        IF startnumber <= V_RANGES.serialnumberstart AND V_RANGES.e <= endnumber THEN
            DELETE FROM snap_p2.serialnumberusage
                WHERE id = V_RANGES.id;
        END IF;
    END LOOP;
    CLOSE c_ranges
    /* insert the allocation */;
    SELECT
        nextval('snap_p2.serialnumberusage_id_sequence')
        INTO STRICT newIDSN;
    INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id)
    VALUES (newIDSN, formcodeid, startnumber, allocationQuantity, aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB'), v_allocationDate, allocationid, bspid)
    /* historize the allocation */;
    SELECT
        *
        FROM snap_p2.historize(formcodeid := formcodeid, startnumber := startnumber, endnumber := endnumber, quantity := quantity, bspid := bspid, doctypeid := documentTypeID, docsubtypeid := papertypeid, gdsid := gdsid, printerid := printerid, validitydate := validitydate, purchaseorder := purchaseordernumber, statuscode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_ALLOCATION'), rangestatus := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB'), operationdate := v_allocationDate)
        INTO errorcode;
    EXCEPTION
        WHEN others THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
END;

$$;

alter function allocate(numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, timestamp, text, out numeric, out numeric, timestamp) owner to shr_psql_prod;

