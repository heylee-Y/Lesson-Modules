create function "pack_serial_ranges$findfreerange"(p_formcodeid numeric, p_quantity numeric, p_blacklistpercent numeric, p_nrinteruptions numeric, p_startingfromnumber numeric, INOUT p_opennumber numeric, INOUT p_closenumber numeric) returns record
  language plpgsql
as
$$
DECLARE

    V_ROWBLACKSN snap_p2.blacklistsn%ROWTYPE;

    C_BLACKLISTSN REFCURSOR;

    V_FOUND NUMERIC(38);

    V_DIFF NUMERIC(38);

    V_COUNT_BREAKS NUMERIC(38);

    V_COUNT_BLACK_NUMBERS NUMERIC(38);

    V_PERCENT_BLACKSN NUMERIC;

    V_TEMP_OPENNUMBER NUMERIC;

    V_TEMP_CLOSENUMBER NUMERIC;

    v_rangeStart NUMERIC DEFAULT NULL;

    v_rangeEnd NUMERIC DEFAULT NULL;

    f$result BOOLEAN;

BEGIN

    p_opennumber := - 1;

    p_closenumber := - 1

    /* initializearza p_openNumber cu start number daca e nenul */;

 

    IF COALESCE(p_startingfromnumber, - 1) > - 1 THEN

        v_rangeStart := p_startingfromnumber;

        v_rangeEnd := p_startingfromnumber;

    END IF;

    SELECT

        *

        FROM snap_p2.pack_serial_ranges$get_next_range_tosearch(p_formcodeid, v_rangeStart)

        INTO v_rangeStart, v_rangeEnd, f$result;

 

    WHILE f$result

    /* calculez cate black numbers am in intervalul asta , daca am */

    /* V_COUNT_BLACK_NUMBERS := CALCULATE_BLACKLIST_NUMBERS_IN_INTERVAL( P_FORMCODEID, P_OPENNUMBER, P_OPENNUMBER + P_QUANTITY -1 ); */

    LOOP

     

 

 

                                                IF COALESCE(p_quantity, 0) <= (v_rangeEnd - v_rangeStart + 1) THEN

                                                                    p_opennumber := v_rangeStart;

            p_closenumber := p_opennumber + COALESCE(p_quantity, 0) -1;

                                                                                                EXIT;

                                                END IF;

                                                                   

        v_rangeStart := v_rangeEnd + 1;

    END LOOP;

END;

$$;

alter function "pack_serial_ranges$findfreerange"(numeric, numeric, numeric, numeric, numeric, inout numeric, inout numeric) owner to shr_psql_prod;

