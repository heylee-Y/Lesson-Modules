create function gettodaydate() returns timestamp without time zone
  language plpgsql
as
$$
BEGIN
    RETURN TO_DATE(TO_CHAR(aws_oracle_ext.SYSDATE(), 'dd/mm/yyyy'), 'dd/mm/yyyy');
END;

$$;

alter function gettodaydate() owner to shr_psql_prod;

