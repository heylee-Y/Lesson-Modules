create function "pack_serial_ranges$get_blacklist_quantity"(p_formcodeid double precision, p_s double precision, p_e double precision) returns double precision
  language plpgsql
as
$$
DECLARE
    v_ret DOUBLE PRECISION DEFAULT 0;
BEGIN
    SELECT
        SUM(snap_p2.pack_serial_ranges$calc_partial_bl_quantity(opennumber, closenumber, p_s, p_e))
        INTO STRICT v_ret
        FROM snap_p2.blacklistsn AS bl
        WHERE bl.formcode_id = p_formcodeid AND snap_p2.pack_serial_ranges$are_intervals_overlaying(p_s, p_e, bl.opennumber, bl.closenumber) = 1;
    RETURN v_ret;
END;

$$;

alter function "pack_serial_ranges$get_blacklist_quantity"(double precision, double precision, double precision) owner to shr_psql_prod;

