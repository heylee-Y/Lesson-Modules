create function "housekeeping$compactrages"(p_rg1_id numeric, p_rg1_start numeric, p_rg1_quantity numeric, p_rg1_statuschangedate timestamp without time zone, p_rg2_id numeric, p_formcodeid numeric) returns void
    language plpgsql
as
$$
DECLARE
    v_BspId NUMERIC(38);
    v_Status CHARACTER VARYING(6);
    v_docTypeId NUMERIC(38);
    v_quantity NUMERIC(38);
    v_quantityRange1 NUMERIC(38);
    v_BspId1 NUMERIC(38);
    v_Status1 CHARACTER VARYING(6);
    v_startNumber2 NUMERIC(38);
    v_quantity2 NUMERIC(38);
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    SELECT
        f.fc_documenttype_id
        INTO STRICT v_docTypeId
        FROM snap_p2.formcode AS f
        WHERE f.id = p_formcodeid;
    SELECT
        sn.quantity
        INTO STRICT v_quantityRange1
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.id = p_rg1_id;
    SELECT
        bsp_id, status
        INTO STRICT v_BspId1, v_Status1
        FROM snap_p2.serialnumberusage
        WHERE id = p_rg1_id;
    SELECT
        sn.serialnumberstart
        INTO STRICT v_startNumber2
        FROM snap_p2.serialnumberusage AS sn
        WHERE id = p_rg2_id;
    SELECT
        sn.quantity
        INTO STRICT v_quantity2
        FROM snap_p2.serialnumberusage AS sn
        WHERE id = p_rg2_id;
    DELETE FROM snap_p2.serialnumberusage
        WHERE id = p_rg1_id;
    UPDATE snap_p2.serialnumberusage AS sn
    SET serialnumberstart = p_rg1_start, quantity = sn.quantity + p_rg1_quantity, statuschangedate =
    CASE (sn.statuschangedate - p_rg1_statuschangedate) - ABS(sn.statuschangedate - p_rg1_statuschangedate)
        WHEN 0 THEN sn.statuschangedate
        ELSE p_rg1_statuschangedate
    END
        WHERE sn.id = p_rg2_id;
    SELECT
        sn.quantity
        INTO STRICT v_quantity
        FROM snap_p2.serialnumberusage AS sn
        WHERE id = p_rg2_id;
    SELECT
        bsp_id, status
        INTO STRICT v_BspId, v_Status
        FROM snap_p2.serialnumberusage
        WHERE id = p_rg2_id;
    INSERT INTO snap_p2.history
    VALUES (nextval('snap_p2.history_id_sequence'), p_formcodeid, p_rg1_start, p_rg1_start + v_quantity - 1, 'HKJ', v_quantity, v_BspId, v_Status, aws_oracle_ext.SYSDATE(), aws_oracle_ext.SYSDATE(), v_docTypeId, TO_DATE(aws_oracle_ext.SYSDATE(), 'dd-MM-yyy'));
    DELETE FROM snap_p2.history AS h
        WHERE h.formcodeid = p_formcodeid AND h.startno = p_rg1_start AND h.endno = p_rg1_start + v_quantityRange1 - 1 AND h.quantity = v_quantityRange1 AND h.bspid = v_BspId1 AND h.rangestatus IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I')) AND h.doctypeid = v_docTypeId;
    DELETE FROM snap_p2.history AS h
        WHERE h.formcodeid = p_formcodeid AND h.startno = v_startNumber2 AND h.endno = v_startNumber2 + v_quantity2 - 1 AND h.quantity = v_quantity2 AND h.bspid = v_BspId1 AND h.rangestatus IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I')) AND h.doctypeid = v_docTypeId;
    EXCEPTION
        WHEN others THEN
            RAISE DEBUG USING MESSAGE := SQLERRM;
END;

$$;

alter function "housekeeping$compactrages"(numeric, numeric, numeric, timestamp, numeric, numeric) owner to shr_psql_prod;

