create function logallocatehistory(formcodeid numeric, startnumber numeric, endnumber numeric, quantity numeric, gdsid numeric DEFAULT NULL::numeric, bspid numeric DEFAULT NULL::numeric, printerid numeric DEFAULT NULL::numeric, papertypeid numeric DEFAULT NULL::numeric, validitydate timestamp without time zone DEFAULT NULL::timestamp without time zone, purchaseordernumber text DEFAULT NULL::text, OUT errorcode numeric, allocationdate timestamp without time zone DEFAULT NULL::timestamp without time zone) returns numeric
    language plpgsql
as
$$
DECLARE

    documentTypeID NUMERIC(38);
    v_allocationDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(allocationdate, aws_oracle_ext.SYSDATE());
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
		SELECT
			fc.fc_documenttype_id
			INTO STRICT documentTypeID
			FROM snap_p2.formcode AS fc
			WHERE fc.id = formcodeid;
    /* historize the allocation */
    SELECT
        *
        FROM snap_p2.historize(formcodeid := formcodeid, startnumber := startnumber, endnumber := endnumber, quantity := quantity, bspid := bspid, doctypeid := documentTypeID, docsubtypeid := papertypeid, gdsid := gdsid, printerid := printerid, validitydate := validitydate, purchaseorder := purchaseordernumber, statuscode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_ALLOCATION'), rangestatus := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB'), operationdate := v_allocationDate)
        INTO errorcode;
    EXCEPTION
        WHEN others THEN
            errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
END;

$$;

alter function logallocatehistory(numeric, numeric, numeric, numeric, numeric, numeric, numeric, numeric, timestamp, text, out numeric, timestamp) owner to shr_psql_prod;

