create function changeownerforlargeobject() returns void
  language plpgsql
as
$$
DECLARE
    r numeric;
BEGIN 
	for r in select accreditation_paper from etariffs.user_info where accreditation_paper is not null loop
	execute 'ALTER LARGE OBJECT ' || r || ' OWNER TO etariffs';
    RAISE NOTICE 'update d(%)', r;
	end loop;
END;

$$;

alter function changeownerforlargeobject() owner to postgres;

