create function processsnapno(snapno text, OUT formcodeid double precision, OUT startno double precision, OUT "f$result" boolean) returns record
    language plpgsql
as
$$
DECLARE
    v_formcode CHARACTER VARYING(3);
    v_count NUMERIC(38) DEFAULT 0;
BEGIN
    IF snapno IS NULL OR LENGTH(snapno) <> 10 THEN
        f$result := FALSE;
        RETURN;
    END IF
    /* get first 2 digits */;
    v_formcode := SUBSTR(snapno, 0, 2);
    SELECT
        COUNT(*)
        INTO STRICT v_count
        FROM snap_p2.formcode AS f
        WHERE f.fc_number = v_formcode;

    IF v_count = 1 THEN
        SELECT
            f.id
            INTO STRICT formcodeid
            FROM snap_p2.formcode AS f
            WHERE f.fc_number = v_formcode;
        startno := SUBSTR(snapno, 2)::NUMERIC;
        f$result := TRUE;
        RETURN;
    /* not found , check 3 digits */
    ELSE
        v_formcode := SUBSTR(snapno, 0, 3);
        SELECT
            COUNT(*)
            INTO STRICT v_count
            FROM snap_p2.formcode AS f
            WHERE f.fc_number = v_formcode;

        IF v_count = 1 THEN
            SELECT
                f.id
                INTO STRICT formcodeid
                FROM snap_p2.formcode AS f
                WHERE f.fc_number = v_formcode;
            startno := SUBSTR(snapno, 3)::NUMERIC;
            f$result := TRUE;
            RETURN;
        END IF;
    END IF;
    f$result := FALSE;
    RETURN;
    EXCEPTION
        WHEN others THEN
            f$result := FALSE;
            RETURN;
END;

$$;

alter function processsnapno(text, out double precision, out double precision, out boolean) owner to shr_psql_prod;

