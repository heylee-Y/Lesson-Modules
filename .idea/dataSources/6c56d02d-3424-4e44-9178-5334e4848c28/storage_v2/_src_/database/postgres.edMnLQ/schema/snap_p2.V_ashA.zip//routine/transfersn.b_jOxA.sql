create function transfersn(p_allocationid numeric, p_startnumber numeric, p_endnumber numeric, p_tobspid numeric, p_transferdate timestamp without time zone, OUT p_errorcode numeric, OUT p_transferallocationid numeric) returns record
    language plpgsql
as
$$
DECLARE
    v_sourceBSPID NUMERIC(38) DEFAULT - 1;
    v_sourceStartNumber NUMERIC(38) DEFAULT - 1;
    v_sourceQuantity NUMERIC(38) DEFAULT - 1;
    v_sourceEndNumber NUMERIC(38) DEFAULT - 1;
    v_formCodeId NUMERIC(38) DEFAULT - 1;
    v_tempQuantity NUMERIC(38) DEFAULT 0;
    v_quantityTransferable NUMERIC(38) DEFAULT 0;
    v_transferDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(p_transferdate, aws_oracle_ext.SYSDATE());
    v_tempCursor REFCURSOR;
    v_snStatus CHARACTER VARYING(100);
    v_FormFreezeDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL;
    v_historyAllocationID NUMERIC(38) DEFAULT NULL;
    v_tempSNID NUMERIC(38);
    v_tempSNstartNumber NUMERIC(38);
    v_tempSNendNumber NUMERIC(38);
    v_newAllocationID1 NUMERIC(38) DEFAULT NULL;
    v_newAllocationID2 NUMERIC(38) DEFAULT NULL;
    v_newAllocationIDTransfered NUMERIC(38) DEFAULT NULL;
    v_sourceDTID NUMERIC(38) DEFAULT NULL;
    v_sourceDSubTID NUMERIC(38) DEFAULT NULL;
    v_sourceGdsID NUMERIC(38) DEFAULT NULL;
    v_sourcePrinterID NUMERIC(38) DEFAULT NULL;
    V_ALLOC snap_p2.allocation%ROWTYPE;
    v_tempCount NUMERIC(38) DEFAULT 0;
/* parameters check */
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();

    IF p_endnumber < p_startnumber THEN
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF;
    SELECT
        al.formcode_id, al.bsp_id, al.startnumber, al.quantity, al.endnumber, al.documenttype_id, al.documentsubtype_id, al.gds_id, al.printer_id
        INTO STRICT v_formCodeId, v_sourceBSPID, v_sourceStartNumber, v_sourceQuantity, v_sourceEndNumber, v_sourceDTID, v_sourceDSubTID, v_sourceGdsID, v_sourcePrinterID
        FROM snap_p2.allocation AS al
        WHERE al.id = p_allocationid;

    IF v_sourceBSPID = - 1 THEN
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF
    /* check if formcode is freeze */;
    SELECT
        f.fc_frozen
        INTO STRICT v_FormFreezeDate
        FROM snap_p2.formcode AS f
        WHERE f.id = v_formCodeId;

    IF v_FormFreezeDate IS NOT NULL THEN
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_FORMCODE_FREEZE')::NUMERIC;
        RETURN;
    END IF
    /* check if transfered range is not alocated / or used */
    /* exit also if there is no overlaped intervals in snusage */;
    p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_NOT_FOUND')::NUMERIC;
    OPEN v_tempCursor FOR
    SELECT
        sn.status
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = v_formCodeId AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, p_startnumber, p_endnumber) = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'CT_TRUE')::NUMERIC;

    LOOP
        FETCH v_tempCursor INTO v_snStatus;
        EXIT WHEN (NOT FOUND);
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;

        IF v_snStatus <> aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB') THEN
            p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_IS_USED')::NUMERIC;
            EXIT;
        END IF;
    END LOOP;
    CLOSE v_tempCursor;

    IF p_errorcode <> aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC THEN
        RETURN;
    END IF
    /* ----------------------- */
    /* get the HISTORY PK  for previous allocation */;

    BEGIN
        SELECT
            *
            INTO STRICT v_historyAllocationID
            FROM (SELECT
                h.id
                FROM snap_p2.history AS h
                WHERE (h.status = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_ALLOCATION') OR h.status = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_TRANSFER')) AND h.formcodeid = v_formCodeId AND h.startno = v_sourceStartNumber AND h.endno = v_sourceEndNumber AND h.quantity = v_sourceQuantity AND h.bspid = v_sourceBSPID
                ORDER BY h.historydate DESC) AS hh
            LIMIT 1;
        EXCEPTION
            WHEN others THEN
                NULL;
    END
    /* ----------------------- */
    /* end parameters check */
    /* break the allocation record */;
    SELECT
        *
        INTO STRICT V_ALLOC
        FROM snap_p2.allocation AS a
        WHERE a.id = p_allocationid
    /* <<begin start>> */;

    IF v_sourceStartNumber < p_startnumber
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_tempQuantity :=       computeRealQuantity( v_formCodeId, v_sourcestartnumber, p_startNumber -1 ); */
    THEN
        v_tempQuantity := p_startnumber - v_sourceStartNumber
        /* duplicate old record */;
        SELECT
            nextval('snap_p2.allocation_id_sequence')
            INTO STRICT v_newAllocationID1;
        INSERT INTO snap_p2.allocation (id, startnumber, quantity, endnumber, formcode_id, allocationdate, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
        SELECT
            v_newAllocationID1, v_sourceStartNumber, v_tempQuantity, p_startnumber - 1, al.formcode_id, al.allocationdate, al.documenttype_id, al.documentsubtype_id, al.bsp_id, al.gds_id, al.printer_id, al.validitydate, al.purchaseordernumber
            FROM snap_p2.allocation AS al
            WHERE al.id = p_allocationid;
    END IF
    /* <<middle>> */
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_quantityTransferable := computeRealQuantity( v_formCodeId, p_startNumber, p_endNumber ); */;
    v_quantityTransferable := p_endnumber - p_startnumber + 1;
    SELECT
        nextval('snap_p2.allocation_id_sequence')
        INTO STRICT v_newAllocationIDTransfered;
    INSERT INTO snap_p2.allocation (id, startnumber, quantity, endnumber, formcode_id, allocationdate, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
    SELECT
        v_newAllocationIDTransfered, p_startnumber, v_quantityTransferable, p_endnumber, al.formcode_id, v_transferDate, al.documenttype_id, al.documentsubtype_id, p_tobspid, al.gds_id, al.printer_id, al.validitydate, al.purchaseordernumber
        FROM snap_p2.allocation AS al
        WHERE al.id = p_allocationid;
    SELECT
        currval('snap_p2.allocation_id_sequence')
        INTO STRICT p_transferallocationid
    /* <<end>> */;

    IF p_endnumber < v_sourceEndNumber
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_tempQuantity := computeRealQuantity( v_formCodeId, p_endNumber + 1, v_sourceEndNumber ); */
    THEN
        v_tempQuantity := v_sourceEndNumber - p_endnumber
        /* get new pk */
        /* duplicate old record */;
        SELECT
            nextval('snap_p2.allocation_id_sequence')
            INTO STRICT v_newAllocationID2;
        INSERT INTO snap_p2.allocation (id, startnumber, quantity, endnumber, formcode_id, allocationdate, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
        SELECT
            v_newAllocationID2, p_endnumber + 1, v_tempQuantity, v_sourceEndNumber, al.formcode_id, al.allocationdate, al.documenttype_id, al.documentsubtype_id, al.bsp_id, al.gds_id, al.printer_id, al.validitydate, al.purchaseordernumber
            FROM snap_p2.allocation AS al
            WHERE al.id = p_allocationid;
    END IF
    /* ------------------------------- */;
    OPEN v_tempCursor FOR
    SELECT
        sn.id, sn.serialnumberstart, sn.serialnumberstart + sn.quantity - 1
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = v_formCodeId AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, p_startnumber, p_endnumber) = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'CT_TRUE')::NUMERIC;

    LOOP
        FETCH v_tempCursor INTO v_tempSNID, v_tempSNstartNumber, v_tempSNendNumber;
        EXIT WHEN (NOT FOUND)
        /* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */;

        DECLARE
            tmpStart NUMERIC(38);
            tmpEnd NUMERIC(38);
            tmpQuantity NUMERIC(38);
        BEGIN
            IF v_tempSNstartNumber <= p_startnumber THEN
                tmpStart := p_startnumber;
            ELSE
                tmpStart := v_tempSNstartNumber;
            END IF;

            IF p_endnumber <= v_tempSNendNumber THEN
                tmpEnd := p_endnumber;
            ELSE
                tmpEnd := v_tempSNendNumber;
            END IF;
            tmpQuantity := tmpEnd - tmpStart + 1
            /* <<freebegin>> */;

            IF v_tempSNstartNumber < tmpStart THEN
                v_tempQuantity := tmpStart - v_tempSNstartNumber
                /* duplicate old record */;
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, v_tempSNstartNumber, v_tempQuantity, sn.status, statuschangedate, v_newAllocationID1, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = v_tempSNID;
            END IF
            /* <<allocatedmiddle>> */
            /* duplicate old record */;
            INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
            VALUES (nextval('snap_p2.serialnumberusage_id_sequence'), v_formCodeId, tmpStart, tmpQuantity, aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB'), v_transferDate, v_newAllocationIDTransfered, p_tobspid, NULL)
            /* <<freeend>> */;

            IF tmpEnd < v_tempSNendNumber THEN
                v_tempQuantity := v_tempSNendNumber - tmpEnd
                /* duplicate old record */;
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, tmpEnd + 1, v_tempQuantity, sn.status, statuschangedate, v_newAllocationID2, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = v_tempSNID;
            END IF
            /* <<delete old SN>> */;
            DELETE FROM snap_p2.serialnumberusage AS sn
                WHERE sn.id = v_tempSNID;
        END;
        /* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */
    END LOOP;
    CLOSE v_tempCursor
    /* ------------------------------- */;
    SELECT
        COUNT(*)
        INTO STRICT v_tempCount
        FROM snap_p2.serialnumberusage
        WHERE allocation_id = p_allocationid
    /* <<delete old allocation record>> */;

    IF v_tempCount = 0 THEN
        DELETE FROM snap_p2.allocation
            WHERE id = p_allocationid;
    END IF
    /* historize the transfer */
    /* Call the procedure */;
    SELECT
        *
        FROM snap_p2.historize(formcodeid := v_formCodeId, doctypeid := v_sourceDTID, docsubtypeid := v_sourceDSubTID, startnumber := p_startnumber, endnumber := p_endnumber, quantity := v_quantityTransferable, bspid := p_tobspid, bspoldid := v_sourceBSPID, printerid := v_sourcePrinterID
        /* trensfer from printer */, gdsid := v_sourceGdsID, statuscode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_TRANSFER'), historyreferencedid := v_historyAllocationID, rangestatus := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB'), operationdate := v_transferDate, validitydate := V_ALLOC.validitydate, purchaseorder := V_ALLOC.purchaseordernumber)
        INTO p_errorcode;
    EXCEPTION
        WHEN others THEN
            p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
END;

$$;

alter function transfersn(numeric, numeric, numeric, numeric, timestamp, out numeric, out numeric) owner to shr_psql_prod;

