create function setval_max(inc integer) returns void
  language plpgsql
as
$$
  -- Sets all the sequences in the schema "schema_name" to the max(id) of every table (or a specific table, if name is supplied)
-- Examples:
--  SELECT setval_max('public');
--  SELECT setval_max('public','mytable');
--  SELECT setval_max('public',null,true);
--  SELECT setval_max('public','mytable',true);

DECLARE
    r pg_class%rowtype;
    i name;
    isit integer;
BEGIN 
	FOR i in SELECT c.relname from pg_class c where c.relkind = 'S' and c.relnamespace=16387 LOOP
		--isit := POSITION('pv_' in i);
		--IF (isit = 1) THEN 
		--	execute 'select last_value from visionr.' || i into isit;
		--	execute 'alter sequence visionr.' || i || ' restart with ' || (isit+inc);
		  EXECUTE 'SELECT setval(''snap_p2.' || i || ''', (SELECT nextval(''snap_p2.' || i || '''))+200);';

			RAISE NOTICE 'update d(%)', i::varchar;
	--	END IF;
	END LOOP;
END;
$$;

alter function setval_max(integer) owner to postgres;

