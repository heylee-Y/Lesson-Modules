create function "housekeeping$compactformcode"(p_formcodeid numeric) returns void
    language plpgsql
as
$$
DECLARE
    c_ranges CURSOR FOR
    SELECT
        snuse.id, snuse.serialnumberstart AS s, snuse.serialnumberstart + snuse.quantity - 1 AS e, snuse.quantity, snuse.status, snuse.statuschangedate, snuse.allocation_id
        FROM snap_p2.serialnumberusage AS snuse
        WHERE snuse.formcode_id = p_formcodeid AND snuse.status
        /* snappkg.sn_status_free , */
        IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I')
        /* , */
        /* snappkg.sn_status_retrieve_a, */
        /* snappkg.sn_status_retrieve_q */)
        ORDER BY snuse.serialnumberstart;
    V_RANGES_1 record;
    V_RANGES_2 record;
    c_ranges$FOUND BOOLEAN DEFAULT false;
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    OPEN c_ranges;

    LOOP
        FETCH c_ranges INTO V_RANGES_2;
        c_ranges$FOUND := FOUND;
        EXIT WHEN (NOT c_ranges$FOUND);

        IF V_RANGES_1.id IS NULL THEN
            V_RANGES_1 := V_RANGES_2
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_RANGE
            */;
        END IF;

        IF V_RANGES_1.status = V_RANGES_2.status AND V_RANGES_1.e + 1 = V_RANGES_2.serialnumberstart
        /* daca e aloocation, verifica sa faca parte din aceeasi alocare */
        THEN
            IF V_RANGES_2.status IN (aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AA'), aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_I')) THEN
                IF V_RANGES_1.allocation_id <> V_RANGES_2.allocation_id THEN
                    V_RANGES_1 := V_RANGES_2
                    /*
                    [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
                    GOTO NEXT_RANGE
                    */;
                END IF;
            END IF;
            PERFORM snap_p2.housekeeping$compactrages(V_RANGES_1.id, V_RANGES_1.serialnumberstart, V_RANGES_1.quantity, V_RANGES_1.statuschangedate, V_RANGES_2.id, p_formcodeid);
            SELECT
                snuse.id, snuse.serialnumberstart AS s, snuse.serialnumberstart + snuse.quantity - 1 AS e, snuse.quantity, snuse.status, snuse.statuschangedate, snuse.allocation_id
                INTO STRICT V_RANGES_1
                FROM snap_p2.serialnumberusage AS snuse
                WHERE snuse.id = V_RANGES_2.id
            /*
            [5335 - Severity CRITICAL - PostgreSQL doesn't support the GOTO operator. Perform a manual conversion.]
            GOTO NEXT_RANGE
            */;
        END IF;
        V_RANGES_1 := V_RANGES_2;
    END LOOP;
    CLOSE c_ranges;
    EXCEPTION
        WHEN others THEN
            NULL;
END;

$$;

alter function "housekeeping$compactformcode"(numeric) owner to shr_psql_prod;

