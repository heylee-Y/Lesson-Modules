create function getformcodeidfromserialnumber(snapno numeric) returns numeric
  language plpgsql
as
$$
DECLARE
    v_serial CHARACTER VARYING(20) DEFAULT TRIM(TO_CHAR(snapno, '0000000000'));
    v_formcode CHARACTER VARYING(5);
    v_count NUMERIC(38) DEFAULT 0;
    formcodeID NUMERIC(38) DEFAULT NULL;
BEGIN
    IF snapno IS NULL OR LENGTH(v_serial) <> 10 THEN
        RETURN NULL;
    END IF;
    v_formcode := SUBSTR(v_serial, 0, 3);
    SELECT
        COUNT(*)
        INTO STRICT v_count
        FROM snap_p2.formcode AS f
        WHERE f.fc_number = v_formcode;

    IF v_count = 1 THEN
        SELECT
            f.id
            INTO STRICT formcodeID
            FROM snap_p2.formcode AS f
            WHERE f.fc_number = v_formcode;
        RETURN formcodeID;
    /* not found , check 2 digits */
    ELSE
        v_formcode := SUBSTR(v_serial, 0, 2);
        SELECT
            COUNT(*)
            INTO STRICT v_count
            FROM snap_p2.formcode AS f
            WHERE f.fc_number = v_formcode;

        IF v_count = 1 THEN
            SELECT
                f.id
                INTO STRICT formcodeID
                FROM snap_p2.formcode AS f
                WHERE f.fc_number = v_formcode;
            RETURN formcodeID;
        END IF;
    END IF;
    RETURN NULL;
    EXCEPTION
        WHEN others THEN
            RETURN NULL;
END;

$$;

alter function getformcodeidfromserialnumber(numeric) owner to shr_psql_prod;

