create function isoverlapping(startno numeric, quantity numeric, openno numeric, closeno numeric) returns numeric
    language plpgsql
as
$$
BEGIN
    RETURN snap_p2.isoverlapping2(startno, startno + quantity - 1, openno, closeno);
END;

$$;

alter function isoverlapping(numeric, numeric, numeric, numeric) owner to shr_psql_prod;

