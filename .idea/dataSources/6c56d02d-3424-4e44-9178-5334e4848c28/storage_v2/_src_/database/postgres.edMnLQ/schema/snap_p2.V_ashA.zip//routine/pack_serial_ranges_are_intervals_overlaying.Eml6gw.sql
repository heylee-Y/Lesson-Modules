create function "pack_serial_ranges$are_intervals_overlaying"(d1 double precision, d2 double precision, d3 double precision, d4 double precision) returns double precision
  language plpgsql
as
$$
BEGIN
    IF snap_p2.pack_serial_ranges$isnumberininterval(d1, d3, d4) = 1 THEN
        RETURN 1;
    END IF;

    IF snap_p2.pack_serial_ranges$isnumberininterval(d3, d1, d2) = 1 THEN
        RETURN 1;
    END IF;
    RETURN 0;
END;

$$;

alter function "pack_serial_ranges$are_intervals_overlaying"(double precision, double precision, double precision, double precision) owner to shr_psql_prod;

