create function retrieve(p_allocationid numeric, p_startnumber numeric, p_endnumber numeric, retrivedate timestamp without time zone, OUT p_errorcode integer, p_retrievestatus text DEFAULT NULL::text, p_is_manual_retieve numeric DEFAULT 1, p_reasonforretrieve text DEFAULT NULL::text) returns integer
  language plpgsql
as
$$
DECLARE
    v_sourceBSPID NUMERIC(38) DEFAULT NULL;
    v_sourcePrinterID NUMERIC(38) DEFAULT NULL;
    v_sourceStartNumber NUMERIC(38) DEFAULT - 1;
    v_sourceQuantity NUMERIC(38) DEFAULT - 1;
    v_sourceEndNumber NUMERIC(38) DEFAULT - 1;
    v_formCodeId NUMERIC(38) DEFAULT - 1;
    v_tempQuantity NUMERIC(38) DEFAULT 0;
    v_sourceDTID NUMERIC(38) DEFAULT NULL;
    v_sourceDSubTID NUMERIC(38) DEFAULT NULL;
    v_sourceGdsID NUMERIC(38) DEFAULT NULL;
    v_tempCount NUMERIC(38) DEFAULT 0
    /* newID integer; */;
    v_quantityRetrived NUMERIC(38) DEFAULT 0;
    v_retriveDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT COALESCE(retrivedate, aws_oracle_ext.SYSDATE());
    v_statusRetieve CHARACTER VARYING(100) DEFAULT COALESCE(p_retrievestatus, aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_RETRIEVE_A'));
    v_frozenDate TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL;
    v_tempCursor REFCURSOR;
    v_snStatus CHARACTER VARYING(100);
    v_tempSNID NUMERIC(38);
    v_tempSNstartNumber NUMERIC(38);
    v_tempSNendNumber NUMERIC(38)
    /* type intArray is varying array(1000) of integer; */
    /* indexesSN intArray; */;
    v_historyAllocationID NUMERIC(38) DEFAULT NULL;
    v_newAllocationID1 NUMERIC(38) DEFAULT NULL;
    v_newAllocationID2 NUMERIC(38) DEFAULT NULL;
/* parameters check */
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();

    IF p_endnumber < p_startnumber THEN
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF;
    SELECT
        al.formcode_id, al.bsp_id, al.printer_id, al.startnumber, al.quantity, al.endnumber, al.documenttype_id, al.documentsubtype_id, al.gds_id
        INTO STRICT v_formCodeId, v_sourceBSPID, v_sourcePrinterID, v_sourceStartNumber, v_sourceQuantity, v_sourceEndNumber, v_sourceDTID, v_sourceDSubTID, v_sourceGdsID
        FROM snap_p2.allocation AS al
        WHERE al.id = p_allocationid;

    IF v_sourceBSPID IS NULL AND v_sourcePrinterID IS NULL THEN
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF
    /* check if transfered range is not alocated / or used */
    /* exit also if there is no overlaped intervals in snusage */;
    p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_NOT_FOUND')::NUMERIC;
    OPEN v_tempCursor FOR
    SELECT
        sn.status
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = v_formCodeId AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, p_startnumber, p_endnumber) = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'CT_TRUE')::NUMERIC;

    LOOP
        FETCH v_tempCursor INTO v_snStatus;
        EXIT WHEN (NOT FOUND);
        p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;

        IF v_snStatus <> aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_ALLOCATED_AB') THEN
            p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_RANGE_IS_USED')::NUMERIC;
            EXIT;
        END IF;
    END LOOP;
    CLOSE v_tempCursor;

    IF p_errorcode <> aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC THEN
        RETURN;
    END IF
    /* ----------------------- */
    /* get the HISTORY PK  for previous allocation */;

    BEGIN
        SELECT
            *
            INTO STRICT v_historyAllocationID
            FROM (SELECT
                h.id
                FROM snap_p2.history AS h
                WHERE (h.status = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_ALLOCATION') OR h.status = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_TRANSFER')) AND h.formcodeid = v_formCodeId AND h.startno = v_sourceStartNumber AND h.endno = v_sourceEndNumber AND ((v_sourceBSPID IS NOT NULL AND h.bspid = v_sourceBSPID) OR (v_sourcePrinterID IS NOT NULL AND h.printerid = v_sourcePrinterID))
                ORDER BY h.historydate DESC) AS hh
            LIMIT 1;
        EXCEPTION
            WHEN others THEN
                NULL;
    END
    /* ----------------------- */
    /* end parameters check */
    /* in case if the formcode is frozen, the retrieve status MUST BE QUARANTINED */;
    SELECT
        fc.fc_frozen
        INTO STRICT v_frozenDate
        FROM snap_p2.formcode AS fc
        WHERE fc.id = v_formCodeId;

    IF v_frozenDate IS NOT NULL THEN
        v_statusRetieve := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_RETRIEVE_Q');
    END IF
    /* break the allocation record */
    /* <<begin start>> */;

    IF v_sourceStartNumber < p_startnumber
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_tempQuantity := computeRealQuantity( v_formCodeId, v_sourcestartnumber, p_startNumber -1 ); */
    THEN
        v_tempQuantity := p_startnumber - v_sourceStartNumber
        /* duplicate old record */;
        SELECT
            nextval('snap_p2.allocation_id_sequence')
            INTO STRICT v_newAllocationID1;
        INSERT INTO snap_p2.allocation (id, startnumber, quantity, endnumber, formcode_id, allocationdate, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
        SELECT
            v_newAllocationID1, v_sourceStartNumber, v_tempQuantity, p_startnumber - 1, al.formcode_id, al.allocationdate, al.documenttype_id, al.documentsubtype_id, al.bsp_id, al.gds_id, al.printer_id, al.validitydate, al.purchaseordernumber
            FROM snap_p2.allocation AS al
            WHERE al.id = p_allocationid;
    END IF
    /* <<middle>> */
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_quantityRetrived := computeRealQuantity( v_formCodeId, p_startNumber, p_endNumber ); */;
    v_quantityRetrived := p_endnumber - p_startnumber + 1
    /* no additiona record in case of retrive , */
    /* it will break snuseage record and will set the status to available or quarantined */
    /* <<end>> */;

    IF p_endnumber < v_sourceEndNumber
    /* tempQuantity := sourceEndNumber - endNumber; */
    /* CALC QUANTITY WITHOUT BLACKLISTED VALUES */
    /* v_tempQuantity := computeRealQuantity( v_formCodeId, p_endNumber + 1, v_sourceEndNumber ); */
    THEN
        v_tempQuantity := v_sourceEndNumber - p_endnumber
        /* get new pk */;
        SELECT
            nextval('snap_p2.allocation_id_sequence')
            INTO STRICT v_newAllocationID2
        /* duplicate old record */;
        INSERT INTO snap_p2.allocation (id, startnumber, quantity, endnumber, formcode_id, allocationdate, documenttype_id, documentsubtype_id, bsp_id, gds_id, printer_id, validitydate, purchaseordernumber)
        SELECT
            v_newAllocationID2, p_endnumber + 1, v_tempQuantity, v_sourceEndNumber, al.formcode_id, al.allocationdate, al.documenttype_id, al.documentsubtype_id, al.bsp_id, al.gds_id, al.printer_id, al.validitydate, al.purchaseordernumber
            FROM snap_p2.allocation AS al
            WHERE al.id = p_allocationid;
    END IF
    /* break the SERIALNUMBERUSAGE allocated record , so the retrived subrange to be with right status */
    /* all record must have sn-allocated ( not used ) */
    /* ------------------------------- */;
    OPEN v_tempCursor FOR
    SELECT
        sn.id, sn.serialnumberstart, sn.serialnumberstart + sn.quantity - 1
        FROM snap_p2.serialnumberusage AS sn
        WHERE sn.formcode_id = v_formCodeId AND snap_p2.isoverlapping(sn.serialnumberstart, sn.quantity, p_startnumber, p_endnumber) = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'CT_TRUE')::NUMERIC;

    LOOP
        FETCH v_tempCursor INTO v_tempSNID, v_tempSNstartNumber, v_tempSNendNumber;
        EXIT WHEN (NOT FOUND)
        /* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */;

        DECLARE
            tmpStart NUMERIC(38);
            tmpEnd NUMERIC(38);
            tmpQuantity NUMERIC(38);
        BEGIN
            IF v_tempSNstartNumber <= p_startnumber THEN
                tmpStart := p_startnumber;
            ELSE
                tmpStart := v_tempSNstartNumber;
            END IF;

            IF p_endnumber <= v_tempSNendNumber THEN
                tmpEnd := p_endnumber;
            ELSE
                tmpEnd := v_tempSNendNumber;
            END IF;
            tmpQuantity := tmpEnd - tmpStart + 1
            /* <<freebegin>> */;

            IF v_tempSNstartNumber < tmpStart THEN
                v_tempQuantity := tmpStart - v_tempSNstartNumber
                /* duplicate old record */;
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, v_tempSNstartNumber, v_tempQuantity, sn.status, statuschangedate, v_newAllocationID1, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = v_tempSNID;
            END IF
            /* <<allocatedmiddle>> */
            /* duplicate old record */;
            INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
            VALUES (nextval('snap_p2.serialnumberusage_id_sequence'), v_formCodeId, tmpStart, tmpQuantity, v_statusRetieve, v_retriveDate, NULL,
            CASE p_is_manual_retieve
                WHEN 0 THEN v_sourceBSPID
                ELSE NULL
            END, p_is_manual_retieve)
            /* <<freeend>> */;

            IF tmpEnd < v_tempSNendNumber THEN
                v_tempQuantity := v_tempSNendNumber - tmpEnd
                /* duplicate old record */;
                INSERT INTO snap_p2.serialnumberusage (id, formcode_id, serialnumberstart, quantity, status, statuschangedate, allocation_id, bsp_id, is_manual_retrieve)
                SELECT
                    nextval('snap_p2.serialnumberusage_id_sequence'), sn.formcode_id, tmpEnd + 1, v_tempQuantity, sn.status, statuschangedate, v_newAllocationID2, sn.bsp_id, sn.is_manual_retrieve
                    FROM snap_p2.serialnumberusage AS sn
                    WHERE sn.id = v_tempSNID;
            END IF
            /* <<delete old SN>> */;
            DELETE FROM snap_p2.serialnumberusage AS sn
                WHERE sn.id = v_tempSNID;
        END;
        /* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< */
    END LOOP;
    CLOSE v_tempCursor
    /* ------------------------------- */;
    SELECT
        COUNT(*)
        INTO STRICT v_tempCount
        FROM snap_p2.serialnumberusage
        WHERE allocation_id = p_allocationid
    /* <<delete old allocation record>> */;

    IF v_tempCount = 0 THEN
        DELETE FROM snap_p2.allocation
            WHERE id = p_allocationid;
    END IF
    /* historize the retieve */
    /* Call the procedure */;
    INSERT INTO snap_p2.history (id, formcodeid, startno, endno, status, historydate, quantity, bspid, gdsid, doctypeid, docsubtypeid, printerid, allocationdate, statuschangedate, createdate, history_id, retrieve_status, rangestatus, retrieve_reason)
    VALUES (nextval('snap_p2.history_id_sequence'), v_formCodeId, p_startnumber, p_endnumber, aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'ST_RETRIEVE'), v_retriveDate, v_quantityRetrived, v_sourceBSPID, v_sourceGdsID, v_sourceDTID, v_sourceDSubTID, v_sourcePrinterID, v_retriveDate, v_retriveDate, v_retriveDate, v_historyAllocationID, v_statusRetieve, v_statusRetieve, p_reasonforretrieve);
    EXCEPTION
        WHEN others THEN
            p_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
            RAISE DEBUG USING MESSAGE := CONCAT_WS('', 'eroare : ', SQLERRM);
END;

$$;

alter function retrieve(numeric, numeric, numeric, timestamp, out integer, text, numeric, text) owner to shr_psql_prod;

