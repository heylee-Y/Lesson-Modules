create function "pack_serial_ranges$isnumberininterval"(p_numberchecked double precision, p_numberbegin double precision, p_numberend double precision) returns double precision
  language plpgsql
as
$$
BEGIN
    IF (((p_numberchecked >= p_numberbegin) AND (p_numberchecked <= p_numberend)) OR ((p_numberchecked >= p_numberbegin) AND (p_numberend IS NULL)) OR ((p_numberbegin IS NULL) AND (p_numberchecked <= p_numberend))) THEN
        RETURN 1;
    ELSE
        IF (p_numberbegin IS NULL) AND (p_numberend IS NULL) THEN
            RETURN 1;
        ELSE
            RETURN 0;
        END IF;
    END IF;
END;

$$;

alter function "pack_serial_ranges$isnumberininterval"(double precision, double precision, double precision) owner to shr_psql_prod;

