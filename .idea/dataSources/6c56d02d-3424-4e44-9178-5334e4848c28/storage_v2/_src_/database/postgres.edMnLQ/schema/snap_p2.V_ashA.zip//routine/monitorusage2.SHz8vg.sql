create function monitorusage2(p_formcode double precision DEFAULT NULL::double precision, p_rangestart double precision DEFAULT NULL::double precision, p_rangeend double precision DEFAULT NULL::double precision, p_bspid double precision DEFAULT NULL::double precision, p_bspoldid double precision DEFAULT NULL::double precision, p_doctypeid double precision DEFAULT NULL::double precision, p_docsubtypeid double precision DEFAULT NULL::double precision, p_gdsid double precision DEFAULT NULL::double precision, p_printerid double precision DEFAULT NULL::double precision, p_validitydate timestamp without time zone DEFAULT NULL::timestamp without time zone, p_purchaseorder text DEFAULT NULL::text, p_allocationdate timestamp without time zone DEFAULT NULL::timestamp without time zone, p_statuscode text DEFAULT NULL::text, p_statuschangedate timestamp without time zone DEFAULT NULL::timestamp without time zone, p_frozendate timestamp without time zone DEFAULT NULL::timestamp without time zone, p_pagesize double precision DEFAULT NULL::double precision, p_pagenumber double precision DEFAULT 1, p_resultstype double precision DEFAULT 1, OUT o_errorcode double precision, OUT o_results refcursor, OUT o_countno double precision, p_operationcode text DEFAULT NULL::text, p_formlifecycle timestamp without time zone DEFAULT NULL::timestamp without time zone, p_iscurrentlifecycle text DEFAULT NULL::text) returns record
  language plpgsql
as
$$
DECLARE
    V_RESULT_CURRENT_STATUS NUMERIC(38) DEFAULT 1;
    V_RESULT_BLACKLIST_STATUS NUMERIC(38) DEFAULT 2;
    V_RESULT_FORMHISTORY_STATUS NUMERIC(38) DEFAULT 3;
    V_RESULT_HISTORY_STATUS NUMERIC(38) DEFAULT 4;
    v_pgStart NUMERIC(38) DEFAULT (COALESCE(p_pagenumber, 1) - 1) * COALESCE(p_pagesize, 10) + 1;
    v_pgEnd NUMERIC(38) DEFAULT COALESCE(p_pagenumber, 1) * COALESCE(p_pagesize, 10);
    selectCount CHARACTER VARYING(5000) DEFAULT '';
    selectQuery CHARACTER VARYING(5000);
    tmpSelectQuery CHARACTER VARYING(2000) DEFAULT '';
    v_formCodeID NUMERIC(38) DEFAULT NULL;
    v_endLifeCycle TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL;
    v_e CHARACTER VARYING(1000) DEFAULT '';
    v_getAllRecs BOOLEAN DEFAULT FALSE;
    v_statusCode CHARACTER VARYING(10) DEFAULT p_statuscode;
    v_formLifecycle TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL;
BEGIN
    PERFORM SNAP_P2.SNAPPKG$Init();
    o_countno := 0
    /* if p_pageSize == null, get all results, not just one page of 10 results. Set boolean flag v_getAllRecs to true */;

    IF p_pagesize IS NULL THEN
        v_getAllRecs := TRUE;
    END IF
    /* parameter validation */;

    BEGIN
        IF p_formcode IS NOT NULL THEN
            SELECT
                fc.id
                INTO STRICT v_formCodeID
                FROM snap_p2.formcode AS fc
                WHERE fc.fc_number = p_formcode::TEXT;
        END IF;
        EXCEPTION
            WHEN others THEN
                NULL;
    END
    /* end */;

    IF p_resultstype = V_RESULT_CURRENT_STATUS
    /* ---------------------------------------------------------- */
    /* -------------       CURRENT STATUS    -------------------- */
    /* ---------------------------------------------------------- */
    /* IF p_statusCode is null OR p_statusCode = snappkg.sn_status_blacklisted THEN */
    /* without blacklist numbers */
    THEN
        selectCount := CONCAT_WS('', 'SELECT count(*) ', 'FROM SERIALNUMBERUSAGE SN ', '  left join ALLOCATION AL on SN.ALLOCATION_ID = AL.ID ', 'WHERE ( :formCodeID is null OR SN.FORMCODE_ID = :formCodeID ) AND ', '      ( :rangeStart is null OR :rangeEND is null OR ', '         isoverlapping( SN.SERIALNUMBERSTART, SN.QUANTITY, :rangeStart, :rangeEND ) = 1 ) AND ', '      ( :statusCode is null OR SN.STATUS = :statusCode ) AND ', '      ( :sChDate is null OR SN.STATUSCHANGEDATE >= :sChDate ) AND ', '      ( :bsp is null OR AL.BSP_ID = :bsp ) AND ', '      ( :prnt is null OR AL.PRINTER_ID = :prnt ) AND ', '      ( :gds is null OR AL.GDS_ID = :gds ) AND', '      ( :docType is null OR AL.DOCUMENTTYPE_ID = :docType ) AND', '      ( :docSubType is null OR AL.DOCUMENTSUBTYPE_ID = :docSubType )AND ', '      ( :allocDate is null OR TO_CHAR(AL.ALLOCATIONDATE,''dd/MM/yyyy'') = TO_CHAR(:allocDate, ''dd/MM/yyyy'' ) ) AND', '      ( :valDate is null OR AL.VALIDITYDATE = :valDate ) AND ', '      ( :purOrderNum is null OR AL.PURCHASEORDERNUMBER = :purOrderNum ) ');
        selectQuery := CONCAT_WS('', 'SELECT * FROM ( SELECT  a.*, rownum rn FROM  ( ', 'SELECT FC.FC_NUMBER, DT.DT_NAME, SN.SERIALNUMBERSTART S, SN.SERIALNUMBERSTART + SN.QUANTITY -1 E, SN.QUANTITY Q, SN.STATUS, SN.STATUSCHANGEDATE, DS.dst_name , B.bsp_fullname, P.fullname , G.gds_code, AL.validitydate, AL.purchaseordernumber, ', '(SELECT h.snapnumber FROM HISTORY h WHERE h.id = (SELECT MAX(hi.id) FROM HISTORY hi WHERE ( hi.STARTNO = SN.SERIALNUMBERSTART ) AND (hi.ENDNO = (SN.QUANTITY+SN.SERIALNUMBERSTART-1 )) GROUP BY hi.STARTNO )) ,', ' b.bsp_code FROM SERIALNUMBERUSAGE SN inner join FORMCODE FC on SN.FORMCODE_ID = FC.ID inner join DOCUMENTTYPES DT on FC.FC_DOCUMENTTYPE_ID = DT.ID ', '  left join ALLOCATION AL on SN.ALLOCATION_ID = AL.ID left join documentsubtype  DS on AL.documentsubtype_id = DS.ID ', '  left join BSP B on AL.BSP_ID = B.ID left join PRINTERS P on AL.PRINTER_ID = P.ID left join GDS G on AL.GDS_ID = G.ID ', 'WHERE ( :formCodeID is null OR SN.FORMCODE_ID = :formCodeID ) AND ', '      ( :rangeStart is null OR :rangeEND is null OR isoverlapping( SN.SERIALNUMBERSTART, SN.QUANTITY, :rangeStart, :rangeEND ) = 1 ) AND ', '      ( :statusCode is null OR SN.STATUS = :statusCode ) AND ( :sChDate is null OR SN.STATUSCHANGEDATE >= :sChDate ) AND ', '      ( :bsp is null OR AL.BSP_ID = :bsp ) AND ', '      ( :prnt is null OR AL.PRINTER_ID = :prnt ) AND ', '      ( :gds is null OR AL.GDS_ID = :gds ) AND ', '      ( :docType is null OR AL.DOCUMENTTYPE_ID = :docType)AND ', '      ( :docSubType is null OR AL.DOCUMENTSUBTYPE_ID = :docSubType) AND ', '      ( :allocDate is null OR TO_CHAR(AL.ALLOCATIONDATE,''dd/MM/yyyy'') =TO_CHAR(:allocDate, ''dd/MM/yyyy'' )  ) AND', '      ( :valDate is null OR AL.VALIDITYDATE = :valDate) AND ', '      ( :purOrderNum is null OR AL.PURCHASEORDERNUMBER = :purOrderNum) ')
        /* 'ORDER BY SN.STATUSCHANGEDATE DESC ) a ) '; */
        /* 'ORDER BY  TO_CHAR(FC.FC_NUMBER), SN.SERIALNUMBERSTART ) a ) '; */
        /* ADD START */;

        IF (p_formcode IS NOT NULL) AND (p_rangestart IS NULL) AND (p_rangeend IS NULL) AND (p_bspid IS NULL) AND (p_bspoldid IS NULL) AND (p_doctypeid IS NULL) AND (p_docsubtypeid IS NULL) AND (p_gdsid IS NULL) AND (p_printerid IS NULL) AND (p_validitydate IS NULL) AND (p_purchaseorder IS NULL) AND (p_allocationdate IS NULL) AND (p_statuschangedate IS NULL) AND (p_frozendate IS NULL) THEN
            selectQuery := CONCAT_WS('', selectQuery, ' ORDER BY TO_CHAR(FC.FC_NUMBER), SN.SERIALNUMBERSTART');
        ELSE
            selectQuery := CONCAT_WS('', selectQuery, ' ORDER BY SN.STATUSCHANGEDATE DESC');
        END IF
        /* 'ORDER BY  TO_CHAR(FC.FC_NUMBER), SN.SERIALNUMBERSTART ) a ) '; */
        /* ORDER BY SN.STATUSCHANGEDATE DESC */;
        selectQuery := CONCAT_WS('', selectQuery, ' ) a ) ')
        /* ADD END */
        /* if v_getAllRecs is false, then we get only one page of results, thus including the paging clause as follows */;

        IF v_getAllRecs = FALSE THEN
            selectQuery := CONCAT_WS('', selectQuery, ' WHERE rn BETWEEN :pgS AND :pgE ');
        END IF
        /* am */;

        IF p_statuscode = aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'SN_STATUS_BLACKLISTED') THEN
            v_statusCode := '';
        ELSE
            v_statusCode := p_statuscode;
        END IF
        /*
        [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
        EXECUTE IMMEDIATE selectCount INTO o_countNo USING
                          v_formCodeID, v_formCodeID,
                          p_rangeStart, p_rangeEnd,
                          p_rangeStart, p_rangeEnd,
                          v_statusCode, v_statusCode,
                          p_statusChangeDate, p_statusChangeDate,
                          p_bspID, p_bspID,
                          p_printerID, p_printerID,
                          p_gdsID,p_gdsID,
        				  p_docTypeID,p_docTypeID,
        				  p_docSubTypeID,p_docSubTypeID,
        				  p_allocationDate,p_allocationDate,
        				  p_validityDate,p_validityDate,
        				  p_purchaseOrder,p_purchaseOrder
        */
        /* if v_getAllRecs is false, then we get only one page of results, thus including the parameters :v_pgStart, :v_pgEnd for cursor */;

        IF v_getAllRecs = FALSE THEN
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING
                              v_formCodeID, v_formCodeID,
                              p_rangeStart, p_rangeEnd,
                              p_rangeStart, p_rangeEnd,
                              v_statusCode, v_statusCode,
                              p_statusChangeDate, p_statusChangeDate,
                              p_bspID, p_bspID,
                              p_printerID, p_printerID,
                              p_gdsID,p_gdsID,
            				  p_docTypeID,p_docTypeID,
            				  p_docSubTypeID,p_docSubTypeID,
            				  p_allocationDate,p_allocationDate,
            				  p_validityDate,p_validityDate,
            				  p_purchaseOrder,p_purchaseOrder,
                              v_pgStart,v_pgEND
            */
            BEGIN
            END;
        /* else it means v_getAllREcs is true, so we return all results, thus excluding the last 2 params, :v_pgStart and :v_pgEnd */
        ELSE
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING
                              v_formCodeID, v_formCodeID,
                              p_rangeStart, p_rangeEnd,
                              p_rangeStart, p_rangeEnd,
                              v_statusCode, v_statusCode,
                              p_statusChangeDate, p_statusChangeDate,
                              p_bspID, p_bspID,
                              p_printerID, p_printerID,
                              p_gdsID,p_gdsID,
            				  p_docTypeID,p_docTypeID,
            				  p_docSubTypeID,p_docSubTypeID,
            				  p_allocationDate,p_allocationDate,
            				  p_validityDate,p_validityDate,
            				  p_purchaseOrder,p_purchaseOrder
            */
            BEGIN
            END;
        END IF;
    /* end if for the v_getAllRecs comparison */
    ELSIF p_resultstype = V_RESULT_BLACKLIST_STATUS
    /* ---------------------------------------------------------- */
    /* -------------       BLACKLIST       -------------------- */
    /* ---------------------------------------------------------- */
    THEN
        selectCount := CONCAT_WS('', 'SELECT count(*) ', 'FROM blacklistsn BL, FORMCODE FC ', 'WHERE (BL.FORMCODE_ID = FC.ID) and  ( :formCodeID is null OR BL.FORMCODE_ID = :formCodeID ) AND ', '      ( :rangeStart is null OR :rangeEND is null OR ', '         isoverlapping2( BL.OPENNUMBER, BL.CLOSENUMBER, :rangeStart, :rangeEND ) = 1 ', ' OR (BL.OPENNUMBER > :rangeStart AND BL.CLOSENUMBER < Calc_Max_Sn(:rangeStart))  ) ');
        selectQuery := CONCAT_WS('', 'SELECT * FROM ( ', '    SELECT  a.*, rownum rn FROM  ( ', 'SELECT FC.FC_NUMBER, DT.DT_NAME, BL.OPENNUMBER,  BL.CLOSENUMBER, BL.REASON, BL.CODE, BL.BLACKLISTEDDATE ', 'FROM blacklistsn BL ', '     inner join FORMCODE FC on BL.FORMCODE_ID = FC.ID ', '     inner join DOCUMENTTYPES DT on FC.FC_DOCUMENTTYPE_ID = DT.ID ', 'WHERE ( :formCodeID is null OR BL.FORMCODE_ID = :formCodeID ) AND ', '      ( :rangeStart is null OR :rangeEND is null OR ', '         isoverlapping2( BL.OPENNUMBER, BL.CLOSENUMBER, :rangeStart, :rangeEND ) = 1 ', ' OR (BL.OPENNUMBER > :rangeStart AND BL.CLOSENUMBER <Calc_Max_Sn(:rangeStart))  ) ', 'ORDER BY  TO_CHAR(FC.FC_NUMBER), BL.OPENNUMBER ', ' ) a ) ')
        /* if v_getAllRecs is false, then we get one page of results, thus including the page limitation clause as follows */;

        IF v_getAllRecs = FALSE THEN
            selectQuery := CONCAT_WS('', selectQuery, ' WHERE rn BETWEEN :pgS AND :pgE ');
        END IF
        /*
        [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
        EXECUTE IMMEDIATE selectCount INTO o_countNo USING
                    v_formCodeID, v_formCodeID,
                    p_rangeStart, p_rangeEnd,
                    p_rangeStart, p_rangeEnd , p_rangeStart, p_rangeStart
        */
        /* if v_getAllRecs is false, then we get one page of results, thus including the last 2 params, :v_pgStart and :v_pgEnd for cursor */;

        IF v_getAllRecs = FALSE THEN
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING
                            v_formCodeID, v_formCodeID,
                            p_rangeStart, p_rangeEnd,
                            p_rangeStart, p_rangeEnd, p_rangeStart, p_rangeStart,
                            v_pgStart,v_pgEND
            */
            BEGIN
            END;
        /* else it means v_getAllREcs is true, so we return all results, thus excluding the last 2 params, :v_pgStart and :v_pgEnd */
        ELSE
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING
                            v_formCodeID, v_formCodeID,
                            p_rangeStart, p_rangeEnd,
                            p_rangeStart, p_rangeEnd, p_rangeStart, p_rangeStart
            */
            BEGIN
            END;
        END IF;
    /* end if for v_getAllRecs comparison */
    ELSIF p_resultstype = V_RESULT_FORMHISTORY_STATUS
    /* ---------------------------------------------------------- */
    /* -------------       FORMHISTORY       -------------------- */
    /* ---------------------------------------------------------- */
    THEN
        IF v_formCodeID IS NULL THEN
            v_formCodeID := snap_p2.getformcodeidfromserialnumber(p_rangestart);
        END IF;

        IF v_formCodeID IS NULL THEN
            o_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
            RETURN;
        END IF;
        selectCount := CONCAT_WS('', 'SELECT count(*) ', 'FROM formhistory FH ', '     inner join FORMCODE FC on FC.ID = FH.FORMCODE_ID ', 'WHERE FH.FORMCODE_ID = :formcode ')
        /* if v_getAllRecs is false, we return one page of results. this implies including the next substring to the query */;
        selectQuery := '';

        IF v_getAllRecs = FALSE THEN
            selectQuery := 'SELECT * FROM ( SELECT  a.*, rownum rn FROM  ( ';
        END IF;
        selectQuery := CONCAT_WS('', selectQuery, 'SELECT FH.FC_NUMBER , DT.DT_NAME, FH.FC_COMMENT, FH.FC_RESO, FH.UPDATE_DATE, FH.FC_FROZEN, FH.FC_FROZEN_FOR,FH.IS_OVERRIDDEN ', 'FROM formhistory FH ', '     inner join FORMCODE FC on FC.ID = FH.FORMCODE_ID ', '     inner join DOCUMENTTYPES DT on DT.ID = FH.FC_DOCUMENTTYPE_ID ', 'WHERE FH.FORMCODE_ID = :formcode ', 'ORDER BY FH.UPDATE_DATE DESC ')
        /* || */
        /* if v_getAllRecs is false, then we get only one page of results, thus including the paging clause as follows: */;

        IF v_getAllRecs = FALSE THEN
            selectQuery := CONCAT_WS('', selectQuery, ' ) a )  WHERE rn BETWEEN :pgS AND :pgE ');
        END IF
        /*
        [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
        EXECUTE IMMEDIATE selectCount INTO o_countNo USING
                    v_formCodeID
        */
        /* if v_getAllRecs is false, then we get only one page of results, thus including the paging params :v_pgStart and :v_pgEnd */;

        IF v_getAllRecs = FALSE THEN
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING
                           v_formCodeID,
                           v_pgStart,v_pgEND
            */
            BEGIN
            END;
        END IF;

        IF v_getAllRecs = TRUE
        /* else we return all results, thus excluding the last 2 params, :v_pgStart and :v_pgEnd */
        THEN
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            OPEN o_Results FOR selectQuery USING v_formCodeID
            */
            BEGIN
            END;
        END IF;
    /* end if for v_getAllRecs is true */
    ELSIF p_resultstype = V_RESULT_HISTORY_STATUS
    /* ---------------------------------------------------------- */
    /* -------------       ACTION HISTORY       ----------------- */
    /* ---------------------------------------------------------- */
    /* Changes made for removing the time from comparisions and included check for the old bsp code */
    THEN
        tmpSelectQuery := CONCAT_WS('', 'FROM history h ', '  left join formcode f on h.formCodeID = f.id  ', '  left join DOCUMENTTYPES DT on h.doctypeid = DT.ID ', '  left join documentsubtype  DS on h.docsubtypeid = DS.ID ', '  left join bsp b on  b.id = h.bspID ', '  left join bsp bold on  bold.id = h.bspoldid ', '  left join printers p on  p.id = h.printerID ', '  left join gds g on  g.id = h.gdsID ', 'WHERE ( :formCodeID is null OR h.FORMCODEID = :formCodeID ) AND ', '      ( :rangeStart is null OR :rangeEND is null OR ', '         isoverlapping2( h.STARTNO, h.ENDNO, :rangeStart, :rangeEND ) = 1 ) ');

        IF p_iscurrentlifecycle IS NOT NULL AND p_iscurrentlifecycle = 'true' THEN
            IF v_formCodeID IS NULL THEN
                v_formCodeID := snap_p2.getformcodeidfromserialnumber(p_rangestart);
            END IF;
            SELECT
                MAX(fh.update_date)
                INTO STRICT v_formLifecycle
                FROM snap_p2.formhistory AS fh
                WHERE fh.formcode_id = v_formCodeID;
        ELSE
            v_formLifecycle := p_formlifecycle;
        END IF;

        IF v_formLifecycle IS NOT NULL THEN
            IF v_formCodeID IS NULL THEN
                v_formCodeID := snap_p2.getformcodeidfromserialnumber(p_rangestart);
            END IF;
            v_endLifeCycle := snap_p2.getlifecycleenddate(v_formCodeID, v_formLifecycle);
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, ' and h.historydate >= :d1 AND h.historydate < :d2 ');
        END IF;

        IF p_bspid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and ( h.bspid = ', p_bspid);
        END IF
        /* bspOldID in integer default null, */;

        IF p_bspoldid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, ' or h.bspoldid = ', p_bspoldid, ')');
        END IF;

        IF p_doctypeid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.doctypeid = ', p_doctypeid);
        END IF;

        IF p_docsubtypeid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.docsubtypeid = ', p_docsubtypeid);
        END IF;

        IF p_gdsid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.gdsID = ', p_gdsid);
        END IF;

        IF p_printerid IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.printerID = ', p_printerid);
        END IF;

        IF p_validitydate IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and TO_CHAR(h.validityDate,''dd/MM/yyyy'') = ''', TO_CHAR(p_validitydate, 'dd/MM/yyyy'), ''' ');
        END IF;

        IF p_purchaseorder IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.purchaseNumber LIKE ''%', p_purchaseorder, '%''');
        END IF;

        IF p_allocationdate IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and TO_CHAR(h.allocationDate,''dd/MM/yyyy'') = ''', TO_CHAR(p_allocationdate, 'dd/MM/yyyy'), ''' ');
        END IF;

        IF p_statuscode IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.RANGESTATUS = ''', p_statuscode, '''');
        END IF;

        IF p_statuschangedate IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and TO_CHAR(h.statusChangeDate,''dd/MM/yyyy'') = ''', TO_CHAR(p_statuschangedate, 'dd/MM/yyyy'), ''' ');
        END IF;

        IF p_frozendate IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and TO_CHAR(h.freezeDate,''dd/MM/yyyy'') = ''', TO_CHAR(p_frozendate, 'dd/MM/yyyy'), ''' ');
        END IF;

        IF p_operationcode IS NOT NULL THEN
            tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, 'and h.STATUS = ''', p_operationcode, '''');
        END IF;
        tmpSelectQuery := CONCAT_WS('', tmpSelectQuery, ' and h.statuschangedate is not null');
        selectCount := CONCAT_WS('', 'SELECT count(*) ', tmpSelectQuery);
        selectQuery := CONCAT_WS('', 'SELECT * FROM ( ', '    SELECT  a.*, rownum rn FROM  ( ', 'SELECT f.fc_number ol, DT.DT_NAME, DS.dst_name , h.startno, h.endno, h.quantity, h.RANGESTATUS , h.status, ', '       b.BSP_FULLNAME b1, bold.BSP_FULLNAME b2, g.gds_code, p.fullname, h.validityDate ,h.purchasenumber, h.CREATEDATE, h.SNAPNUMBER,b.bsp_code bc1,bold.bsp_code bc2 ', tmpSelectQuery)
        /* ' order by h.startno, h.endno, h.statuschangedate ' || */
        /* ' ) a ) '; */
        /* ADD START */;

        IF (p_formcode IS NOT NULL) AND (p_rangestart IS NULL) AND (p_rangeend IS NULL) AND (p_bspid IS NULL) AND (p_bspoldid IS NULL) AND (p_doctypeid IS NULL) AND (p_docsubtypeid IS NULL) AND (p_gdsid IS NULL) AND (p_printerid IS NULL) AND (p_validitydate IS NULL) AND (p_purchaseorder IS NULL) AND (p_allocationdate IS NULL) AND (p_statuschangedate IS NULL) AND (p_frozendate IS NULL) THEN
            selectQuery := CONCAT_WS('', selectQuery, ' order by h.startno, h.endno, h.statuschangedate');
        ELSE
            selectQuery := CONCAT_WS('', selectQuery, ' order by h.statuschangedate desc');
        END IF;
        selectQuery := CONCAT_WS('', selectQuery, ' ) a ) ')
        /* ADD END */
        /* if  v_getAllRecs is false, then we return only one page of results, thus including the paging clause as follows */;

        IF v_getAllRecs = FALSE THEN
            selectQuery := CONCAT_WS('', selectQuery, ' WHERE rn BETWEEN :pgS AND :pgE ');
        END IF;

        IF v_formLifecycle IS NOT NULL THEN
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            EXECUTE IMMEDIATE selectCount INTO o_countNo USING
                          v_formCodeID, v_formCodeID,
                          p_rangeStart, p_rangeEnd,
                          p_rangeStart, p_rangeEnd,
                          v_formLifecycle, v_endLifeCycle
            */
            /* if v_getAllRecs is false, then we return one page of results, thus including the paging params :v_pgStart and :v_pgEnd */
            IF v_getAllRecs = FALSE THEN
                /*
                [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
                OPEN o_Results FOR selectQuery USING
                                       v_formCodeID,v_formCodeID,
                                       p_rangeStart, p_rangeEnd,
                                       p_rangeStart, p_rangeEnd,
                                       v_formLifecycle, v_endLifeCycle,
                                       v_pgStart,v_pgEND
                */
                BEGIN
                END;
            /* else we bring all results, thus excluding the last 2 params, :v_pgStart and :v_pgEnd */
            ELSE
                /*
                [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
                OPEN o_Results FOR selectQuery USING
                                       v_formCodeID,v_formCodeID,
                                       p_rangeStart, p_rangeEnd,
                                       p_rangeStart, p_rangeEnd,
                                       v_formLifecycle, v_endLifeCycle
                */
                BEGIN
                END;
            END IF;
        /* end if for v_getAllRecs comparison */
        ELSE
            /*
            [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
            EXECUTE IMMEDIATE selectCount INTO o_countNo USING
                          v_formCodeID, v_formCodeID,
                          p_rangeStart, p_rangeEnd,
                          p_rangeStart, p_rangeEnd
            */
            /* if v_getAllRecs is false, then we return one page of results, thus including the params :v_pgStart and :v_pgEnd for cursor */
            IF v_getAllRecs = FALSE THEN
                /*
                [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
                OPEN o_Results FOR selectQuery USING
                                   v_formCodeID,v_formCodeID,
                                   p_rangeStart, p_rangeEnd,
                                   p_rangeStart, p_rangeEnd,
                                  v_pgStart,v_pgEND
                */
                BEGIN
                END;
            /* else we bring all results, thus excluding the last 2 params, :v_pgStart and :v_pgEnd from cursor clause */
            ELSE
                /*
                [5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion., 5334 - Severity CRITICAL - Unable convert statements with dynamic SQL statement. Please perform a manual conversion.]
                OPEN o_Results FOR selectQuery USING
                                   v_formCodeID,v_formCodeID,
                                   p_rangeStart, p_rangeEnd,
                                   p_rangeStart, p_rangeEnd
                */
                BEGIN
                END;
            END IF;
        /* end if for v_getAllRecs comparison */
        END IF;
    /* ---------------------------------------------------------- */
    /* -------------       ERROR       ----------------- */
    /* ---------------------------------------------------------- */
    ELSE
        o_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_INVALID_PARAMS')::NUMERIC;
        RETURN;
    END IF;
    o_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'S_OK')::NUMERIC;
    EXCEPTION
        WHEN others THEN
            o_errorcode := aws_oracle_ext.get_package_variable('SNAP_P2', 'SNAPPKG', 'E_UNKNOWN')::NUMERIC;
            v_e := SQLERRM;
            RAISE DEBUG USING MESSAGE := SQLERRM;
END;

$$;

alter function monitorusage2(double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, timestamp, text, timestamp, text, timestamp, timestamp, double precision, double precision, double precision, out double precision, out refcursor, out double precision, text, timestamp, text) owner to shr_psql_prod;

