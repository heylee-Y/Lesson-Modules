create function calc_partial_bl_quantity(blstartno double precision, blendno double precision, openno double precision, closeno double precision) returns double precision
    language plpgsql
as
$$
DECLARE
    result NUMERIC(38) DEFAULT 0;
    tempStart NUMERIC(38) DEFAULT 0;
    tempEnd NUMERIC(38) DEFAULT 0;
BEGIN
    IF blstartno <= openno THEN
        tempStart := openno;
    ELSE
        tempStart := blstartno;
    END IF;

    IF closeno <= blendno THEN
        tempEnd := closeno;
    ELSE
        tempEnd := blendno;
    END IF;

    IF tempEnd < tempStart THEN
        RETURN 0;
    END IF;
    RETURN (tempEnd - tempStart + 1);
END;

$$;

alter function calc_partial_bl_quantity(double precision, double precision, double precision, double precision) owner to shr_psql_prod;

