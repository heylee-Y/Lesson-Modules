create function "migration$init"() returns void
  language plpgsql
as
$$
BEGIN
if aws_oracle_ext.is_package_initialized
      ( 'SNAP_P2', 'MIGRATION' ) then
      return;
    end if;
    perform aws_oracle_ext.set_package_initialized
      ( 'SNAP_P2', 'MIGRATION' );

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_CONNECTIONTYPE_CONVERTED', 'CONVERTED'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_CONNECTIONTYPE_SCRATCH', 'SCRATCH'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_DUMMYFLAG_TRUE', 'Y'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_FILTERTYPE_ALL', 0);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_FILTERTYPE_NAMELIST', 1);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_FILTERTYPE_OBJECTIDLIST', 3);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_FILTERTYPE_WHERECLAUSE', 2);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_INDEXTYPE_CONTEXT', 'ctxsys.context'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_INDEXTYPE_CTXCAT', 'ctxsys.ctxcat'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_LANGUAGEID_ORACLE', 'OracleSQL'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_CLUSTERS', 'NS_CLUSTERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_CONSTRAINTS', 'NS_CONSTRAINTS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_DATABASE', 'NS_DATABASE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_DB_TRIGGERS', 'NS_DB_TRIGGERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_DIMENSIONS', 'NS_DIMENSIONS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_INDEXES', 'NS_INDEXES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_PRIVATE_DBLINKS', 'NS_PRIVATEDBLINKS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_PROFILES', 'NS_PROFILES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_PUBLIC_DBLINKS', 'NS_PUBLICDBLINKS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_PUBLIC_SYNONYMS', 'NS_PUB_SYNONYMS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_SCHEMA_OBJS', 'NS_SCHEMAOBJS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_TABLESPACES', 'NS_TABLESPACES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_USERS', 'NS_USERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NS_USER_ROLES', 'NS_USERROLES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_NULLABLE_YES', 'Y'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_CATALOGS', 'MD_CATALOGS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_CNSTRNT_DETAILS', 'MD_CONSTRAINT_DETAILS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_COLUMNS', 'MD_COLUMNS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_CONNECTIONS', 'MD_CONNECTIONS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_CONSTRAINTS', 'MD_CONSTRAINTS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_GROUPS', 'MD_GROUPS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_GROUP_MEMBERS', 'MD_GROUPMEMBERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_INDEXES', 'MD_INDEXES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_INDEX_DETAILS', 'MD_INDEX_DETAILS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_OTHER_OBJECTS', 'MD_OTHER_OBJECTS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_PACKAGES', 'MD_PACKAGES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_PRIVILEGES', 'MD_PRIVILEGES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_SCHEMAS', 'MD_SCHEMAS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_SEQUENCES', 'MD_SEQUENCES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_STORED_PROGRAMS', 'MD_STORED_PROGRAMS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_SYNONYMS', 'MD_SYNONYMS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_TABLES', 'MD_TABLES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_TABLESPACES', 'MD_TABLESPACES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_TRIGGERS', 'MD_TRIGGERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_UDDT', 'MD_USER_DEFINED_DATA_TYPES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_USERS', 'MD_USERS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_USER_PRIVILEGES', 'MD_USER_PRIVILEGES'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_OBJECTTYPE_VIEWS', 'MD_VIEWS'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_ALREADY_IDENTITY', 'ALREADYIDENTITY'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_EXTENDEDINDEXTYPE', 'EXTENDEDINDEXTYPE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_INCREMENT', 'INCREMENT'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_LASTVALUE', 'LASTVALUE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_REAL_IDENTITY', 'REALIDENTITY'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_SEEDVALUE', 'SEEDVALUE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_SEQUENCEID', 'SEQUENCEID'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_PROPKEY_TRIGGER_REWRITE', 'TRIGGER_REWRITE'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_ROLE_FLAG', 'R'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_SYNONYM_PRIVATE', 'Y'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'C_TRANSFORMED_TRUE', 'Y'::TEXT);

PERFORM aws_oracle_ext.set_package_variable('SNAP_P2', 'MIGRATION', 'v_prefixName', ''::TEXT);
BEGIN
    NULL;
END;
END;

$$;

alter function "migration$init"() owner to shr_psql_prod;

