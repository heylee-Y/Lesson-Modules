create function isoverlapping2(startno numeric, endno numeric, openno numeric, closeno numeric) returns numeric
    language plpgsql
as
$$
DECLARE
    result NUMERIC(38) DEFAULT 0;
BEGIN
    IF (startno <= openno AND openno <= endno) OR (startno <= closeno AND closeno <= endno) OR (openno <= startno AND endno <= closeno) THEN
        result := 1;
    END IF;
    RETURN result;
END;

$$;

alter function isoverlapping2(numeric, numeric, numeric, numeric) owner to shr_psql_prod;

