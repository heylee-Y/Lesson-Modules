create function truncatealltable() returns text
    language plpgsql
as
$$
DECLARE
	cur_all_tables CURSOR FOR
    	select relname from pg_class where relnamespace = (select oid from pg_namespace where nspname = 'snap_p2')
		and relkind = 'r' order by relname;
    truncate_sql CHARACTER VARYING(100);
    drop_sql CHARACTER VARYING(100);
    table_prefixs text array[4];
	prefix text;
BEGIN
	table_prefixs := '{"md_", "migr_", "migration_", "migrlog", "ss2k5_", "stage_", "syb12_"}';
    
	FOR records IN cur_all_tables
    LOOP           
    	truncate_sql := concat('truncate table snap_p2.', records.relname, ' cascade');
    	EXECUTE truncate_sql;
        
        FOREACH  prefix IN ARRAY table_prefixs   
        LOOP
    		if position(prefix in records.relname) = 1 then
            	drop_sql := concat('drop table snap_p2.',records.relname, ' CASCADE');
            	EXECUTE drop_sql;
            end if;
        END LOOP;
    END LOOP;
    return 'success';
END

$$;

alter function truncatealltable() owner to shr_psql_prod;

